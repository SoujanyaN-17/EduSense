// Audio utility functions for generating sound effects

// Extend Window interface for webkit support
declare global {
  interface Window {
    webkitAudioContext?: typeof AudioContext;
  }
}

export class AudioUtils {
  private static audioContext: AudioContext | null = null;

  private static getAudioContext(): AudioContext {
    if (!AudioUtils.audioContext) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (AudioContextClass) {
        AudioUtils.audioContext = new AudioContextClass();
      } else {
        throw new Error('AudioContext not supported');
      }
    }
    return AudioUtils.audioContext;
  }

  // Generate pop sound for moderate attention alerts (25-50%)
  static playPopSound(): void {
    try {
      const audioContext = AudioUtils.getAudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Pop sound configuration
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.currentTime + 0.1);

      gainNode.gain.setValueAtTime(0.3, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    } catch (error) {
      console.warn('Could not play pop sound:', error);
    }
  }

  // Generate peep sound for critical attention alerts (<25%)
  static playPeepSound(): void {
    try {
      const audioContext = AudioUtils.getAudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Peep sound configuration (higher pitch, longer duration)
      oscillator.frequency.setValueAtTime(1200, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(1200, audioContext.currentTime + 0.05);
      oscillator.frequency.setValueAtTime(800, audioContext.currentTime + 0.1);
      oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.currentTime + 0.3);

      gainNode.gain.setValueAtTime(0.4, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.4, audioContext.currentTime + 0.05);
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime + 0.1);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.3);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.3);
    } catch (error) {
      console.warn('Could not play peep sound:', error);
    }
  }

  // Generate success sound for target completion
  static playSuccessSound(): void {
    try {
      const audioContext = AudioUtils.getAudioContext();
      
      // Create a sequence of ascending notes
      const notes = [523.25, 659.25, 783.99]; // C5, E5, G5
      
      notes.forEach((frequency, index) => {
        const oscillator = audioContext.createOscillator();
        const gainNode = audioContext.createGain();

        oscillator.connect(gainNode);
        gainNode.connect(audioContext.destination);

        oscillator.frequency.setValueAtTime(frequency, audioContext.currentTime + index * 0.15);
        
        gainNode.gain.setValueAtTime(0.3, audioContext.currentTime + index * 0.15);
        gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + index * 0.15 + 0.3);

        oscillator.start(audioContext.currentTime + index * 0.15);
        oscillator.stop(audioContext.currentTime + index * 0.15 + 0.3);
      });
    } catch (error) {
      console.warn('Could not play success sound:', error);
    }
  }

  // Generate warning sound for looking away
  static playWarningSound(): void {
    try {
      const audioContext = AudioUtils.getAudioContext();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();

      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);

      // Warning sound configuration (alternating frequencies)
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime);
      oscillator.frequency.setValueAtTime(880, audioContext.currentTime + 0.2);
      oscillator.frequency.setValueAtTime(440, audioContext.currentTime + 0.4);

      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime);
      gainNode.gain.setValueAtTime(0.2, audioContext.currentTime + 0.4);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.6);

      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.6);
    } catch (error) {
      console.warn('Could not play warning sound:', error);
    }
  }
}
