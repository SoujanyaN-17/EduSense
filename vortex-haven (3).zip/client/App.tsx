import "./global.css";

import { Toaster } from "@/components/ui/toaster";
import { createRoot } from "react-dom/client";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Landing from "./pages/Landing";
import Dashboard from "./pages/Dashboard";
import TestDashboard from "./pages/TestDashboard";
import SimpleDashboard from "./pages/SimpleDashboard";
import EnhancedDashboard from "./pages/EnhancedDashboard";
import Learning from "./pages/Learning";
import LearningInterface from "./pages/LearningInterface";
import EnhancedLearningInterface from "./pages/EnhancedLearningInterface";
import ImprovedLearningInterface from "./pages/ImprovedLearningInterface";
import Onboarding from "./pages/Onboarding";
import Settings from "./pages/Settings";
import SettingsPage from "./pages/SettingsPage";
import Admin from "./pages/Admin";
import Login from "./pages/Login";
import Register from "./pages/Register";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/onboarding" element={<Onboarding />} />
          <Route path="/demo" element={<SimpleDashboard />} />
          <Route path="/dashboard" element={<EnhancedDashboard />} />
          <Route path="/test-dashboard" element={<TestDashboard />} />
          <Route path="/learn/:courseId" element={<Learning />} />
          <Route path="/learning/:courseId" element={<LearningInterface />} />
          <Route path="/enhanced-learning/:courseId" element={<EnhancedLearningInterface />} />
          <Route path="/improved-learning/:courseId" element={<ImprovedLearningInterface />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/admin" element={<Admin />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

createRoot(document.getElementById("root")!).render(<App />);
