import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { Brain, GraduationCap, Target, BookOpen, Camera, ArrowRight, CheckCircle } from "lucide-react";

interface OnboardingData {
  personalInfo: {
    fullName: string;
    age: string;
    grade: string;
    learningGoals: string[];
  };
  academicInfo: {
    subjects: string[];
    difficultyLevel: string;
    studyTime: string;
    preferredStyle: string;
  };
  preferences: {
    cameraConsent: boolean;
    attentionTracking: boolean;
    notifications: boolean;
    dataSharing: boolean;
  };
}

export default function Onboarding() {
  const navigate = useNavigate();
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);

  const [onboardingData, setOnboardingData] = useState<OnboardingData>({
    personalInfo: {
      fullName: "",
      age: "",
      grade: "",
      learningGoals: []
    },
    academicInfo: {
      subjects: [],
      difficultyLevel: "",
      studyTime: "",
      preferredStyle: ""
    },
    preferences: {
      cameraConsent: false,
      attentionTracking: false,
      notifications: false,
      dataSharing: false
    }
  });

  const totalSteps = 4;
  const progress = (currentStep / totalSteps) * 100;

  // Age groups for personalized experience
  const ageGroups = [
    { value: "5-8", label: "5-8 years old", description: "Elementary (Early)" },
    { value: "9-11", label: "9-11 years old", description: "Elementary (Late)" },
    { value: "12-14", label: "12-14 years old", description: "Middle School" },
    { value: "15-17", label: "15-17 years old", description: "High School" },
    { value: "18-22", label: "18-22 years old", description: "College" },
    { value: "23+", label: "23+ years old", description: "Adult Learner" }
  ];

  // Grade levels
  const gradeLevels = [
    "Kindergarten", "1st Grade", "2nd Grade", "3rd Grade", "4th Grade", "5th Grade",
    "6th Grade", "7th Grade", "8th Grade", "9th Grade", "10th Grade", "11th Grade", "12th Grade",
    "College Freshman", "College Sophomore", "College Junior", "College Senior", "Graduate Student", "Professional"
  ];

  // Learning goals based on age
  const getLearningGoals = () => {
    const age = onboardingData.personalInfo.age;
    if (age.includes("5-8") || age.includes("9-11")) {
      return [
        "Learn to read better", "Improve math skills", "Science exploration", 
        "Creative writing", "Art and creativity", "Problem solving"
      ];
    } else if (age.includes("12-14") || age.includes("15-17")) {
      return [
        "Improve grades", "Prepare for tests", "Learn programming", "Science projects",
        "Language learning", "Creative skills", "College preparation", "Study habits"
      ];
    } else {
      return [
        "Career advancement", "New skills", "Programming", "Data science",
        "Business skills", "Language learning", "Creative pursuits", "Personal development"
      ];
    }
  };

  // Subjects based on grade level
  const getSubjects = () => {
    const grade = onboardingData.personalInfo.grade;
    if (grade.includes("Kindergarten") || grade.includes("1st") || grade.includes("2nd") || grade.includes("3rd")) {
      return [
        "Reading & Writing", "Basic Math", "Science Fun", "Art & Crafts", "Music", "Physical Education"
      ];
    } else if (grade.includes("4th") || grade.includes("5th") || grade.includes("6th")) {
      return [
        "English Language Arts", "Mathematics", "Science", "Social Studies", "Art", "Music", "Physical Education"
      ];
    } else if (grade.includes("7th") || grade.includes("8th") || grade.includes("9th")) {
      return [
        "English", "Algebra", "Geometry", "Biology", "Chemistry", "Physics", "History", "Geography", "Computer Science"
      ];
    } else if (grade.includes("10th") || grade.includes("11th") || grade.includes("12th")) {
      return [
        "Advanced English", "Calculus", "AP Biology", "AP Chemistry", "AP Physics", "AP History", 
        "Computer Science", "Economics", "Psychology", "Statistics"
      ];
    } else {
      return [
        "Mathematics", "Computer Science", "Data Science", "Business", "Engineering", 
        "Medicine", "Law", "Psychology", "Languages", "Arts", "Sciences"
      ];
    }
  };

  const updatePersonalInfo = (field: string, value: string | string[]) => {
    setOnboardingData(prev => ({
      ...prev,
      personalInfo: {
        ...prev.personalInfo,
        [field]: value
      }
    }));
  };

  const updateAcademicInfo = (field: string, value: string | string[]) => {
    setOnboardingData(prev => ({
      ...prev,
      academicInfo: {
        ...prev.academicInfo,
        [field]: value
      }
    }));
  };

  const updatePreferences = (field: string, value: boolean) => {
    setOnboardingData(prev => ({
      ...prev,
      preferences: {
        ...prev.preferences,
        [field]: value
      }
    }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleComplete = async () => {
    setIsLoading(true);
    
    // Save onboarding data to localStorage
    localStorage.setItem("neurolearn_user_profile", JSON.stringify(onboardingData));
    localStorage.setItem("neurolearn_onboarding_complete", "true");
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      navigate("/dashboard");
    }, 2000);
  };

  const isStepValid = () => {
    switch (currentStep) {
      case 1:
        return onboardingData.personalInfo.fullName && onboardingData.personalInfo.age && onboardingData.personalInfo.grade;
      case 2:
        return onboardingData.personalInfo.learningGoals.length > 0;
      case 3:
        return onboardingData.academicInfo.subjects.length > 0 && onboardingData.academicInfo.difficultyLevel && onboardingData.academicInfo.studyTime;
      case 4:
        return onboardingData.preferences.cameraConsent;
      default:
        return false;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-xl">
              <Brain className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                NeuroLearn AI
              </h1>
              <p className="text-sm text-muted-foreground">Personalized Learning Setup</p>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Progress indicator */}
        <div className="max-w-2xl mx-auto mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold">Getting Started</h2>
            <span className="text-sm text-muted-foreground">Step {currentStep} of {totalSteps}</span>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex justify-between mt-2 text-xs text-muted-foreground">
            <span>Personal Info</span>
            <span>Learning Goals</span>
            <span>Academic Preferences</span>
            <span>Privacy Settings</span>
          </div>
        </div>

        {/* Step 1: Personal Information */}
        {currentStep === 1 && (
          <Card className="max-w-2xl mx-auto animate-in slide-in-from-right duration-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Tell us about yourself</CardTitle>
              <CardDescription>
                This helps us create a personalized learning experience just for you!
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="fullName">What's your full name?</Label>
                <Input
                  id="fullName"
                  placeholder="Enter your full name"
                  value={onboardingData.personalInfo.fullName}
                  onChange={(e) => updatePersonalInfo("fullName", e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label>How old are you?</Label>
                <Select value={onboardingData.personalInfo.age} onValueChange={(value) => updatePersonalInfo("age", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your age group" />
                  </SelectTrigger>
                  <SelectContent>
                    {ageGroups.map((age) => (
                      <SelectItem key={age.value} value={age.value}>
                        <div>
                          <div className="font-medium">{age.label}</div>
                          <div className="text-xs text-muted-foreground">{age.description}</div>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>What grade are you in?</Label>
                <Select value={onboardingData.personalInfo.grade} onValueChange={(value) => updatePersonalInfo("grade", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select your grade level" />
                  </SelectTrigger>
                  <SelectContent>
                    {gradeLevels.map((grade) => (
                      <SelectItem key={grade} value={grade}>
                        {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="outline" disabled>
                  Back
                </Button>
                <Button onClick={handleNext} disabled={!isStepValid()} className="gap-2">
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Learning Goals */}
        {currentStep === 2 && (
          <Card className="max-w-2xl mx-auto animate-in slide-in-from-right duration-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Target className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">What do you want to learn?</CardTitle>
              <CardDescription>
                Choose your learning goals so we can recommend the best content for you.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Label>Select your learning goals (choose as many as you like):</Label>
                <div className="grid grid-cols-2 gap-3">
                  {getLearningGoals().map((goal) => (
                    <div key={goal} className="flex items-center space-x-2">
                      <Checkbox
                        id={goal}
                        checked={onboardingData.personalInfo.learningGoals.includes(goal)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            updatePersonalInfo("learningGoals", [...onboardingData.personalInfo.learningGoals, goal]);
                          } else {
                            updatePersonalInfo("learningGoals", onboardingData.personalInfo.learningGoals.filter(g => g !== goal));
                          }
                        }}
                      />
                      <Label htmlFor={goal} className="text-sm cursor-pointer">
                        {goal}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
                <Button onClick={handleNext} disabled={!isStepValid()} className="gap-2">
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Academic Preferences */}
        {currentStep === 3 && (
          <Card className="max-w-2xl mx-auto animate-in slide-in-from-right duration-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <BookOpen className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Academic Preferences</CardTitle>
              <CardDescription>
                Help us understand your learning style and academic needs.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <Label>Which subjects interest you most?</Label>
                <div className="grid grid-cols-2 gap-3">
                  {getSubjects().map((subject) => (
                    <div key={subject} className="flex items-center space-x-2">
                      <Checkbox
                        id={subject}
                        checked={onboardingData.academicInfo.subjects.includes(subject)}
                        onCheckedChange={(checked) => {
                          if (checked) {
                            updateAcademicInfo("subjects", [...onboardingData.academicInfo.subjects, subject]);
                          } else {
                            updateAcademicInfo("subjects", onboardingData.academicInfo.subjects.filter(s => s !== subject));
                          }
                        }}
                      />
                      <Label htmlFor={subject} className="text-sm cursor-pointer">
                        {subject}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>What's your current difficulty level?</Label>
                <RadioGroup
                  value={onboardingData.academicInfo.difficultyLevel}
                  onValueChange={(value) => updateAcademicInfo("difficultyLevel", value)}
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="beginner" id="beginner" />
                    <Label htmlFor="beginner">Beginner - Just starting out</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="intermediate" id="intermediate" />
                    <Label htmlFor="intermediate">Intermediate - Some experience</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="advanced" id="advanced" />
                    <Label htmlFor="advanced">Advanced - Confident learner</Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="space-y-2">
                <Label>How much time do you want to study per day?</Label>
                <Select value={onboardingData.academicInfo.studyTime} onValueChange={(value) => updateAcademicInfo("studyTime", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select study time" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15-30">15-30 minutes</SelectItem>
                    <SelectItem value="30-60">30-60 minutes</SelectItem>
                    <SelectItem value="1-2">1-2 hours</SelectItem>
                    <SelectItem value="2+">2+ hours</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
                <Button onClick={handleNext} disabled={!isStepValid()} className="gap-2">
                  Next <ArrowRight className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Privacy & Camera Settings */}
        {currentStep === 4 && (
          <Card className="max-w-2xl mx-auto animate-in slide-in-from-right duration-500">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Camera className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Privacy & Camera Settings</CardTitle>
              <CardDescription>
                Configure your privacy preferences and enable AI-powered features.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-6">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <div className="flex items-start space-x-3">
                    <Checkbox
                      id="cameraConsent"
                      checked={onboardingData.preferences.cameraConsent}
                      onCheckedChange={(checked) => updatePreferences("cameraConsent", checked as boolean)}
                    />
                    <div className="space-y-1">
                      <Label htmlFor="cameraConsent" className="font-medium cursor-pointer">
                        Enable Camera for AI Learning (Required)
                      </Label>
                      <p className="text-sm text-muted-foreground">
                        Allow camera access for emotion detection and attention tracking to personalize your learning experience.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="attentionTracking"
                    checked={onboardingData.preferences.attentionTracking}
                    onCheckedChange={(checked) => updatePreferences("attentionTracking", checked as boolean)}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="attentionTracking" className="font-medium cursor-pointer">
                      Real-time Attention Tracking
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Monitor your attention levels and receive helpful suggestions when focus decreases.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="notifications"
                    checked={onboardingData.preferences.notifications}
                    onCheckedChange={(checked) => updatePreferences("notifications", checked as boolean)}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="notifications" className="font-medium cursor-pointer">
                      Learning Notifications
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Receive reminders and notifications about your learning progress and goals.
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Checkbox
                    id="dataSharing"
                    checked={onboardingData.preferences.dataSharing}
                    onCheckedChange={(checked) => updatePreferences("dataSharing", checked as boolean)}
                  />
                  <div className="space-y-1">
                    <Label htmlFor="dataSharing" className="font-medium cursor-pointer">
                      Anonymous Data Sharing
                    </Label>
                    <p className="text-sm text-muted-foreground">
                      Help improve the platform by sharing anonymous learning analytics.
                    </p>
                  </div>
                </div>
              </div>

              <div className="flex justify-between pt-6">
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
                <Button 
                  onClick={handleComplete} 
                  disabled={!isStepValid() || isLoading}
                  className="gap-2"
                >
                  {isLoading ? "Setting up..." : (
                    <>
                      Complete Setup <CheckCircle className="h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
