import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Brain, Eye, EyeOff, TrendingUp } from "lucide-react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login
    setTimeout(() => {
      setIsLoading(false);
      // Check if onboarding is complete
      const onboardingComplete = localStorage.getItem("neurolearn_onboarding_complete");
      if (onboardingComplete === "true") {
        window.location.href = "/dashboard";
      } else {
        window.location.href = "/onboarding";
      }
    }, 1500);
  };

  const isFormValid = email && password;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm">
        <div className="container mx-auto px-4 py-4">
          <Link to="/" className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-xl">
              <Brain className="h-8 w-8 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                NeuroLearn AI
              </h1>
              <p className="text-sm text-muted-foreground">Adaptive Learning Ecosystem</p>
            </div>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-16 flex items-center justify-center min-h-[calc(100vh-100px)]">
        <div className="grid lg:grid-cols-2 gap-12 items-center max-w-6xl w-full">
          {/* Left side - Login Form */}
          <Card className="w-full max-w-md mx-auto">
            <CardHeader className="text-center">
              <CardTitle className="text-2xl">Welcome Back</CardTitle>
              <CardDescription>
                Sign in to continue your personalized learning journey
              </CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Password</Label>
                  <div className="relative">
                    <Input
                      id="password"
                      type={showPassword ? "text" : "password"}
                      placeholder="Enter your password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2 text-muted-foreground hover:text-foreground"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="remember" 
                      checked={rememberMe}
                      onCheckedChange={(checked) => setRememberMe(checked as boolean)}
                    />
                    <Label htmlFor="remember" className="text-sm cursor-pointer">
                      Remember me
                    </Label>
                  </div>
                  <Link to="/forgot-password" className="text-sm text-primary hover:underline">
                    Forgot password?
                  </Link>
                </div>

                <Button 
                  type="submit" 
                  className="w-full" 
                  disabled={!isFormValid || isLoading}
                >
                  {isLoading ? "Signing In..." : "Sign In"}
                </Button>

                <div className="text-center pt-4">
                  <p className="text-sm text-muted-foreground">
                    Don't have an account?{" "}
                    <Link to="/register" className="text-primary hover:underline font-medium">
                      Sign Up
                    </Link>
                  </p>
                </div>
              </form>

              {/* Demo Account */}
              <div className="mt-6 pt-6 border-t">
                <div className="text-center space-y-3">
                  <p className="text-sm text-muted-foreground">Try with demo account:</p>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => {
                      setEmail("demo@neurolearn.ai");
                      setPassword("demo123");
                    }}
                  >
                    Use Demo Account
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Right side - Benefits */}
          <div className="space-y-8 text-center lg:text-left">
            <div>
              <h2 className="text-3xl font-bold mb-4">
                Learn Smarter with AI
              </h2>
              <p className="text-lg text-muted-foreground">
                Experience personalized education that adapts to your emotions and attention patterns in real-time.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="p-2 bg-emotion-happy/10 rounded-lg flex-shrink-0">
                  <Brain className="h-6 w-6 text-emotion-happy" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Emotion-Aware Learning</h3>
                  <p className="text-sm text-muted-foreground">
                    Our AI analyzes your facial expressions to understand your emotional state and adjusts content delivery accordingly.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-2 bg-emotion-focused/10 rounded-lg flex-shrink-0">
                  <Eye className="h-6 w-6 text-emotion-focused" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Attention Tracking</h3>
                  <p className="text-sm text-muted-foreground">
                    Real-time eye movement analysis helps optimize your learning sessions for maximum focus and retention.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="p-2 bg-primary/10 rounded-lg flex-shrink-0">
                  <TrendingUp className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Adaptive Content</h3>
                  <p className="text-sm text-muted-foreground">
                    Course materials automatically adjust to your learning style, pace, and current emotional state.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
