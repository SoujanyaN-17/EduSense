import { useEffect, useRef, useState } from "react";
import { useParams, Link } from "react-router-dom";
import * as faceapi from "face-api.js";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Textarea } from "@/components/ui/textarea";
import { Brain, Camera, Eye, Heart, Activity, ChevronLeft, Play, Pause, SkipForward, Volume2, Fullscreen, NotebookPen, Save, Download } from "lucide-react";

interface EmotionData {
  expression: string;
  confidence: number;
  timestamp: number;
}

interface AttentionData {
  focused: boolean;
  gazeDirection: string;
  blinkRate: number;
  timestamp: number;
}

interface LearningNote {
  id: string;
  content: string;
  timestamp: number;
  emotion: string;
}

export default function Learning() {
  const { courseId } = useParams();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const notesRef = useRef<HTMLTextAreaElement>(null);
  
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [emotions, setEmotions] = useState<EmotionData[]>([]);
  const [attention, setAttention] = useState<AttentionData | null>(null);
  const [currentEmotion, setCurrentEmotion] = useState<string>("neutral");
  const [attentionScore, setAttentionScore] = useState(75);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [cameraStatus, setCameraStatus] = useState<"idle" | "requesting" | "granted" | "denied">("idle");
  
  // Video player state
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolume] = useState(1);
  
  // Notes state
  const [notes, setNotes] = useState<LearningNote[]>([]);
  const [currentNote, setCurrentNote] = useState("");
  
  // Learning content
  const [courseTitle] = useState("Advanced React Patterns");
  const [lessonTitle] = useState("Custom Hooks Deep Dive");
  const [suggestedLearningStyle, setSuggestedLearningStyle] = useState("Visual Learning");

  // Mock lesson content
  const [lessonContent] = useState({
    video: "/placeholder-video.mp4",
    slides: [
      { id: 1, title: "Introduction to Custom Hooks", content: "Learn the fundamentals of creating reusable logic" },
      { id: 2, title: "State Management Patterns", content: "How to manage complex state with custom hooks" },
      { id: 3, title: "Performance Optimization", content: "Optimizing custom hooks for better performance" },
    ]
  });

  // Load face-api.js models and start mock analysis
  useEffect(() => {
    const loadModels = async () => {
      try {
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
          faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
          faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
          faceapi.nets.faceExpressionNet.loadFromUri('/models'),
        ]);
      } catch (error) {
        console.log("Models not found, using mock data");
      }
    };
    loadModels();
    
    // Auto-start analysis for learning session
    startMockAnalysis();
  }, []);

  const startCamera = async () => {
    setCameraStatus("requesting");
    
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera not supported");
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 320 },
          height: { ideal: 240 },
          facingMode: "user"
        }
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        
        videoRef.current.onloadedmetadata = () => {
          videoRef.current?.play().then(() => {
            setCameraStatus("granted");
            setIsCameraActive(true);
            setIsAnalyzing(true);
            startFaceDetection();
          }).catch(() => {
            setCameraStatus("denied");
            startMockAnalysis();
          });
        };
      }
    } catch (error) {
      setCameraStatus("denied");
      startMockAnalysis();
    }
  };

  const startMockAnalysis = () => {
    setIsAnalyzing(true);
    
    const emotions = ["happy", "focused", "neutral", "surprised"];
    const learningStyles = ["Visual Learning", "Auditory Learning", "Kinesthetic Learning", "Reading/Writing"];
    
    const mockInterval = setInterval(() => {
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      const confidence = Math.random() * 0.4 + 0.6;
      
      setCurrentEmotion(randomEmotion);
      setEmotions(prev => [...prev.slice(-5), {
        expression: randomEmotion,
        confidence,
        timestamp: Date.now()
      }]);
      
      const focused = Math.random() > 0.3;
      setAttention({
        focused,
        gazeDirection: Math.random() > 0.5 ? "center" : "away",
        blinkRate: Math.random() * 20 + 10,
        timestamp: Date.now()
      });
      
      setAttentionScore(Math.floor(Math.random() * 30 + 70));
      
      // Update learning style suggestion based on emotion and attention
      if (randomEmotion === "focused" && focused) {
        setSuggestedLearningStyle("Deep Focus Mode");
      } else if (randomEmotion === "happy") {
        setSuggestedLearningStyle("Interactive Learning");
      } else {
        setSuggestedLearningStyle(learningStyles[Math.floor(Math.random() * learningStyles.length)]);
      }
    }, 4000);

    return () => clearInterval(mockInterval);
  };

  const startFaceDetection = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const detectFaces = async () => {
      if (!videoRef.current || !canvasRef.current || !isAnalyzing) return;

      try {
        const detections = await faceapi
          .detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions())
          .withFaceLandmarks()
          .withFaceExpressions();

        if (detections.length > 0) {
          const expressions = detections[0].expressions;
          const dominantExpression = Object.keys(expressions).reduce((a, b) =>
            expressions[a as keyof typeof expressions] > expressions[b as keyof typeof expressions] ? a : b
          );

          setCurrentEmotion(dominantExpression);
          setEmotions(prev => [...prev.slice(-5), {
            expression: dominantExpression,
            confidence: expressions[dominantExpression as keyof typeof expressions],
            timestamp: Date.now()
          }]);
        }
      } catch (error) {
        console.error("Face detection error:", error);
      }

      setTimeout(detectFaces, 2000);
    };

    detectFaces();
  };

  const saveNote = () => {
    if (!currentNote.trim()) return;
    
    const newNote: LearningNote = {
      id: Date.now().toString(),
      content: currentNote,
      timestamp: Date.now(),
      emotion: currentEmotion
    };
    
    setNotes(prev => [...prev, newNote]);
    setCurrentNote("");
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case "happy": return "text-emotion-happy bg-emotion-happy/10";
      case "sad": return "text-emotion-sad bg-emotion-sad/10";
      case "angry": return "text-emotion-angry bg-emotion-angry/10";
      case "surprised": return "text-emotion-surprised bg-emotion-surprised/10";
      case "focused": return "text-emotion-focused bg-emotion-focused/10";
      default: return "text-emotion-neutral bg-emotion-neutral/10";
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ChevronLeft className="h-4 w-4" />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-xl font-bold">{courseTitle}</h1>
                <p className="text-sm text-muted-foreground">{lessonTitle}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="gap-2">
                <Activity className="h-4 w-4" />
                {isAnalyzing ? "Learning Active" : "Paused"}
              </Badge>
              {cameraStatus === "granted" && (
                <Badge variant="default" className="gap-2">
                  <Camera className="h-4 w-4" />
                  AI Monitoring
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-3 space-y-6">
            {/* Video/Slide Area */}
            <Card>
              <CardContent className="p-0">
                <div className="relative bg-black rounded-lg overflow-hidden aspect-video">
                  {/* Mock Video Player */}
                  <div className="absolute inset-0 bg-gradient-to-br from-neutral-800 to-neutral-900 flex items-center justify-center">
                    <div className="text-center text-white">
                      <Play className="h-16 w-16 mx-auto mb-4 opacity-50" />
                      <p className="text-lg">Video Lesson: {lessonTitle}</p>
                      <p className="text-sm opacity-75 mt-2">Click play to start learning</p>
                    </div>
                  </div>
                  
                  {/* Video Controls */}
                  <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/80 to-transparent p-4">
                    <div className="flex items-center gap-4 text-white">
                      <Button size="sm" variant="ghost" className="text-white hover:text-black">
                        {isPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                      </Button>
                      <Button size="sm" variant="ghost" className="text-white hover:text-black">
                        <SkipForward className="h-4 w-4" />
                      </Button>
                      <div className="flex-1">
                        <Progress value={30} className="h-1" />
                      </div>
                      <span className="text-sm">12:45 / 42:30</span>
                      <Button size="sm" variant="ghost" className="text-white hover:text-black">
                        <Volume2 className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="ghost" className="text-white hover:text-black">
                        <Fullscreen className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Notes Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <NotebookPen className="h-5 w-5" />
                  Learning Notes
                </CardTitle>
                <CardDescription>
                  Take notes during the lesson. Your emotions are automatically tracked with each note.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <Textarea
                    ref={notesRef}
                    placeholder="Take notes about what you're learning..."
                    value={currentNote}
                    onChange={(e) => setCurrentNote(e.target.value)}
                    className="min-h-[120px]"
                  />
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Current mood:</span>
                      <Badge size="sm" className={getEmotionColor(currentEmotion)}>
                        {currentEmotion}
                      </Badge>
                    </div>
                    <div className="flex gap-2">
                      <Button onClick={saveNote} size="sm" className="gap-2">
                        <Save className="h-4 w-4" />
                        Save Note
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Saved Notes */}
                {notes.length > 0 && (
                  <div className="space-y-3 border-t pt-4">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium">Saved Notes ({notes.length})</h4>
                      <Button size="sm" variant="outline" className="gap-2">
                        <Download className="h-4 w-4" />
                        Export
                      </Button>
                    </div>
                    <div className="space-y-3 max-h-60 overflow-y-auto">
                      {notes.map((note) => (
                        <div key={note.id} className="p-3 bg-muted rounded-lg">
                          <div className="flex items-start justify-between mb-2">
                            <Badge size="sm" className={getEmotionColor(note.emotion)}>
                              {note.emotion}
                            </Badge>
                            <span className="text-xs text-muted-foreground">
                              {new Date(note.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                          <p className="text-sm">{note.content}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* AI Status Sidebar */}
          <div className="space-y-6">
            {/* Current Emotion */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Heart className="h-5 w-5" />
                  Current Emotion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-4">
                  <Badge className={`text-lg px-4 py-2 ${getEmotionColor(currentEmotion)}`}>
                    {currentEmotion}
                  </Badge>
                  
                  {!isCameraActive && (
                    <Button onClick={startCamera} size="sm" className="gap-2 w-full">
                      <Camera className="h-4 w-4" />
                      Enable Camera
                    </Button>
                  )}
                  
                  {isCameraActive && (
                    <div className="relative bg-neutral-900 rounded-lg overflow-hidden aspect-square">
                      <video
                        ref={videoRef}
                        autoPlay
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                        style={{ transform: "scaleX(-1)" }}
                      />
                      <canvas
                        ref={canvasRef}
                        className="absolute top-0 left-0 w-full h-full"
                        style={{ transform: "scaleX(-1)" }}
                      />
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Attention Percentage */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Eye className="h-5 w-5" />
                  Attention Level
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">{attentionScore}%</div>
                    <p className="text-sm text-muted-foreground">Current Focus</p>
                  </div>
                  <Progress value={attentionScore} className="h-3" />
                  {attention && (
                    <div className="text-center">
                      <Badge variant={attention.focused ? "default" : "secondary"} className="gap-2">
                        <Eye className="h-4 w-4" />
                        {attention.focused ? "Focused" : "Distracted"}
                      </Badge>
                    </div>
                  )}
                  <div className="text-xs text-muted-foreground text-center">
                    {attention?.focused ? "Great focus! Keep it up!" : "Try to minimize distractions"}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Suggested Learning Style */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Brain className="h-5 w-5" />
                  AI Suggestion
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Badge variant="outline" className="w-full justify-center py-2">
                    {suggestedLearningStyle}
                  </Badge>
                  <div className="text-sm text-muted-foreground text-center">
                    {suggestedLearningStyle === "Deep Focus Mode" && "You're in the zone! This is perfect for complex topics."}
                    {suggestedLearningStyle === "Interactive Learning" && "You seem engaged! Try interactive exercises next."}
                    {suggestedLearningStyle === "Visual Learning" && "Visual aids and diagrams work well for you."}
                    {suggestedLearningStyle === "Auditory Learning" && "Try listening to explanations and discussions."}
                    {suggestedLearningStyle === "Kinesthetic Learning" && "Hands-on practice would be beneficial."}
                    {suggestedLearningStyle === "Reading/Writing" && "Taking detailed notes helps your learning."}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Emotions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Emotion History</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {emotions.slice(-4).reverse().map((emotion, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <Badge size="sm" className={getEmotionColor(emotion.expression)}>
                        {emotion.expression}
                      </Badge>
                      <span className="text-muted-foreground">
                        {Math.floor(emotion.confidence * 100)}%
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
