import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
// @ts-ignore
import * as webgazer from "webgazer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Youtube, X, Play, ExternalLink, Camera, Brain, Eye, AlertTriangle, Pause, Target, Settings } from "lucide-react";

export default function SimpleDashboard() {
  const navigate = useNavigate();

  // Emotion detection states
  const [currentEmotion, setCurrentEmotion] = useState("neutral");
  const [confidence, setConfidence] = useState(0.8);
  const [showVideoSuggestions, setShowVideoSuggestions] = useState(false);
  const [lowConfidenceCount, setLowConfidenceCount] = useState(0);

  // Eye tracking and attention states
  const [isEyeTrackingActive, setIsEyeTrackingActive] = useState(false);
  const [attentionLevel, setAttentionLevel] = useState(75);
  const [isLookingAtScreen, setIsLookingAtScreen] = useState(true);
  const [lowAttentionCount, setLowAttentionCount] = useState(0);
  const [showAttentionVideo, setShowAttentionVideo] = useState(false);
  const [currentAttentionVideo, setCurrentAttentionVideo] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [awayFromScreenTime, setAwayFromScreenTime] = useState(0);
  const [isCameraEnabled, setIsCameraEnabled] = useState(false);

  // User interests and YouTube suggestions
  const [userInterests] = useState([
    "programming", "web development", "react", "javascript", "coding tutorials",
    "machine learning", "artificial intelligence", "data science", "tech news"
  ]);
  const [lastSuggestionTime, setLastSuggestionTime] = useState(0);
  const [lastYouTubeSuggestionTime, setLastYouTubeSuggestionTime] = useState(0);

  // Concentration-improving videos for very low attention (<25%)
  const getConcentrationVideos = () => [
    {
      id: "brain-training-1",
      title: "5-Minute Brain Training Exercise",
      thumbnail: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=320&h=180&fit=crop",
      channel: "Focus Academy",
      duration: "5:23",
      views: "2.1M views",
      interest: "concentration"
    },
    {
      id: "attention-boost",
      title: "Quick Attention Boost Techniques",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=320&h=180&fit=crop",
      channel: "MindfulFocus",
      duration: "8:15",
      views: "1.5M views",
      interest: "attention"
    },
    {
      id: "concentration-meditation",
      title: "10-Minute Concentration Meditation",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=320&h=180&fit=crop",
      channel: "Calm Mind",
      duration: "10:34",
      views: "3.2M views",
      interest: "meditation"
    },
    {
      id: "focus-music",
      title: "Binaural Beats for Deep Focus",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=320&h=180&fit=crop",
      channel: "Study Sounds",
      duration: "60:00",
      views: "5.8M views",
      interest: "focus music"
    }
  ];

  // Focus restoration videos (for meditation/breathing - attention 25-49%)
  const focusRestorationVideos = [
    {
      id: "focus1",
      title: "10 Minute Meditation for Focus and Clarity",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=320&h=180&fit=crop",
      channel: "Mindful Learning",
      duration: "10:23",
      views: "2.1M views"
    },
    {
      id: "focus2",
      title: "Quick Breathing Exercises to Reduce Stress",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=320&h=180&fit=crop",
      channel: "Wellness Hub",
      duration: "5:47",
      views: "892K views"
    },
    {
      id: "focus3",
      title: "Forest Sounds for Deep Focus - 1 Hour",
      thumbnail: "https://images.unsplash.com/photo-1441974231531-c6227db76b6e?w=320&h=180&fit=crop",
      channel: "Nature Sounds",
      duration: "60:00",
      views: "5.3M views"
    }
  ];

  // Attention training videos that play when focus is low
  const attentionVideos = [
    {
      id: "attention-1",
      title: "Focus Enhancement Exercise",
      description: "A quick 2-minute exercise to improve your concentration",
      content: "Follow the moving dot with your eyes to train your attention...",
      duration: 120,
      type: "eye-exercise"
    },
    {
      id: "attention-2",
      title: "Breathing Focus Technique",
      description: "Deep breathing to restore mental clarity",
      content: "Take slow, deep breaths while watching the visualization...",
      duration: 180,
      type: "breathing"
    },
    {
      id: "attention-3",
      title: "Visual Attention Training",
      description: "Track objects to improve visual attention",
      content: "Follow the colored shapes as they move across the screen...",
      duration: 150,
      type: "visual-tracking"
    }
  ];

  // Initialize eye tracking and simulation
  useEffect(() => {
    // Start eye tracking simulation
    setIsEyeTrackingActive(true);

    const interval = setInterval(() => {
      const emotions = ["happy", "focused", "neutral", "surprised", "sad", "frustrated"];
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      const randomConfidence = Math.random() * 0.8 + 0.2; // 20% to 100%
      const lookingAway = Math.random() < 0.15; // 15% chance of looking away
      const currentTime = Date.now();

      // Focus percentage should be based on screen attention
      let attentionScore;
      if (!lookingAway) {
        attentionScore = Math.floor(Math.random() * 30) + 70; // 70-100% when looking at screen
      } else {
        attentionScore = Math.floor(Math.random() * 40) + 10; // 10-50% when not looking
      }

      setCurrentEmotion(randomEmotion);
      setConfidence(randomConfidence);
      setAttentionLevel(attentionScore);
      setIsLookingAtScreen(!lookingAway);

      const randomAttention = attentionScore; // Use the calculated attention score

      // FIXED LOGIC: Only show suggestions based on attention levels

      // Attention 50%+ : No suggestions, reset counters
      if (randomAttention >= 50) {
        setLowAttentionCount(0);
        setLowConfidenceCount(0);
        // Hide any open modals after good attention
        if (showAttentionVideo) {
          setTimeout(() => setShowAttentionVideo(false), 2000);
        }
        if (showVideoSuggestions) {
          setTimeout(() => setShowVideoSuggestions(false), 2000);
        }
      }
      // Attention 25-49%: Show attention exercises only (not YouTube)
      else if (randomAttention >= 25 && randomAttention < 50) {
        setLowAttentionCount(prev => {
          const newCount = prev + 1;
          // Only show attention exercises, not YouTube videos
          if (newCount >= 3 && !showAttentionVideo && (currentTime - lastSuggestionTime) > 30000) {
            setShowAttentionVideo(true);
            setCurrentAttentionVideo(Math.floor(Math.random() * attentionVideos.length));
            setLastSuggestionTime(currentTime);
          }
          return newCount;
        });
      }
      // Attention <25%: Show YouTube videos based on user interests
      else if (randomAttention < 25) {
        setLowConfidenceCount(prev => {
          const newCount = prev + 1;
          // Show YouTube videos only for very low attention and not too frequently
          if (newCount >= 2 && !showVideoSuggestions && (currentTime - lastYouTubeSuggestionTime) > 60000) {
            setShowVideoSuggestions(true);
            setLastYouTubeSuggestionTime(currentTime);
          }
          return newCount;
        });
      }

      // Handle looking away from screen
      if (lookingAway) {
        setAwayFromScreenTime(prev => {
          const newTime = prev + 1;
          // If away for more than 5 seconds and video is playing, pause and redirect
          if (newTime >= 5 && isVideoPlaying) {
            setIsVideoPlaying(false);
            setTimeout(() => navigate('/'), 1000);
          }
          return newTime;
        });
      } else {
        setAwayFromScreenTime(0);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [showVideoSuggestions, showAttentionVideo, isVideoPlaying, navigate, lastSuggestionTime, lastYouTubeSuggestionTime]);

  // Camera enablement
  const enableCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" }
      });
      setIsCameraEnabled(true);
      console.log("Camera enabled successfully");

      // You would connect this to actual face detection here
      // For demo, we'll just show it's enabled
    } catch (error) {
      console.error("Camera access denied:", error);
      alert("Camera access denied. Using simulation mode.");
    }
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case "happy": return "text-emotion-happy bg-emotion-happy/10";
      case "sad": return "text-emotion-sad bg-emotion-sad/10";
      case "angry": return "text-emotion-angry bg-emotion-angry/10";
      case "surprised": return "text-emotion-surprised bg-emotion-surprised/10";
      case "focused": return "text-emotion-focused bg-emotion-focused/10";
      default: return "text-emotion-neutral bg-emotion-neutral/10";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <Brain className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                  NeuroLearn AI
                </h1>
                <p className="text-sm text-muted-foreground">Welcome back, Alex!</p>
              </div>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate("/settings")} className="gap-2">
              <Settings className="h-4 w-4" />
              Settings
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Learning Video Player with Attention Monitoring */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  React Masterclass - Complete Course
                  {isVideoPlaying && <Badge size="sm" className="animate-pulse">LIVE</Badge>}
                </CardTitle>
                <CardDescription>
                  Full learning video with intelligent attention monitoring
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative bg-black rounded-xl overflow-hidden aspect-video">
                  {/* Simulated video content */}
                  <div className="absolute inset-0">
                    {isVideoPlaying ? (
                      <div className="bg-gradient-to-br from-slate-800 to-slate-900 h-full flex flex-col">
                        {/* Simulated video timeline */}
                        <div className="flex-1 p-8">
                          <div className="bg-slate-700 rounded-lg p-6 mb-4">
                            <h3 className="text-white text-xl mb-2">Chapter 3: React Hooks Deep Dive</h3>
                            <div className="text-slate-300 text-sm space-y-2">
                              <p>• Understanding useState and useEffect</p>
                              <p>• Custom hooks for reusable logic</p>
                              <p>• Performance optimization techniques</p>
                            </div>
                          </div>
                          <div className="bg-blue-600 rounded p-4">
                            <p className="text-white font-mono text-sm">
                              const [count, setCount] = useState(0);
                              <br />
                              useEffect(() =&gt; &#123; /* effect logic */ &#125;, []);
                            </p>
                          </div>
                        </div>

                        {/* Video controls */}
                        <div className="bg-black/50 p-4">
                          <div className="flex items-center gap-4 text-white text-sm">
                            <span>15:32 / 45:18</span>
                            <div className="flex-1 bg-gray-600 h-1 rounded">
                              <div className="bg-red-500 h-1 rounded w-1/3"></div>
                            </div>
                            <span>HD</span>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
                        <div className="text-center text-white">
                          <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                            <Play className="h-10 w-10 ml-1" />
                          </div>
                          <p className="text-xl font-medium mb-2">React Masterclass</p>
                          <p className="text-sm opacity-75 mb-4">Complete Tutorial Series</p>
                          <div className="text-xs opacity-60">
                            <p>Duration: 45:18 • Instructor: Tech Academy</p>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Attention overlay when looking away */}
                  {isVideoPlaying && !isLookingAtScreen && (
                    <div className="absolute inset-0 bg-red-900/80 flex items-center justify-center animate-in fade-in duration-300">
                      <div className="text-center text-white">
                        <AlertTriangle className="h-12 w-12 mx-auto mb-4 animate-bounce" />
                        <p className="text-xl font-bold mb-2">Video Paused</p>
                        <p className="text-sm">Please look at the screen to continue</p>
                        <p className="text-xs mt-2 opacity-75">
                          Redirecting to home in {Math.max(0, 5 - awayFromScreenTime)}s
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between mt-4">
                  <Button
                    onClick={() => {
                      setIsVideoPlaying(!isVideoPlaying);
                      if (!isVideoPlaying) {
                        setAwayFromScreenTime(0);
                      }
                    }}
                    className="gap-2"
                  >
                    {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    {isVideoPlaying ? "Pause" : "Play"} Demo Video
                  </Button>

                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Eye className="h-4 w-4" />
                    <span>Attention: {attentionLevel}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Emotion Detection Demo</CardTitle>
                <CardDescription>
                  Watch how the system detects low confidence and suggests helpful videos
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <span>Current Emotion:</span>
                  <Badge className={getEmotionColor(currentEmotion)}>
                    {currentEmotion}
                  </Badge>
                </div>
                <div className="flex items-center justify-between">
                  <span>Confidence:</span>
                  <span className={`font-bold ${confidence < 0.5 ? 'text-destructive' : 'text-primary'}`}>
                    {Math.floor(confidence * 100)}%
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span>Low Confidence Count:</span>
                  <span className="font-bold">{lowConfidenceCount}</span>
                </div>
                {confidence < 0.5 && (
                  <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                    <p className="text-sm text-yellow-800">
                      ⚠️ Low confidence detected! Video suggestions will appear after 2 consecutive low readings.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Real-time Attention Level */}
            <Card className={`transition-all duration-300 ${attentionLevel < 50 ? 'border-red-200 bg-red-50/50' : attentionLevel > 80 ? 'border-green-200 bg-green-50/50' : ''}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Eye className={`h-5 w-5 ${isEyeTrackingActive ? 'text-blue-600' : 'text-gray-400'}`} />
                  Live Attention Tracking
                  {isEyeTrackingActive && <Badge size="sm" variant="outline" className="text-xs">LIVE</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className={`text-3xl font-bold transition-colors duration-300 ${
                      attentionLevel < 50 ? 'text-red-600' :
                      attentionLevel > 80 ? 'text-green-600' : 'text-primary'
                    }`}>
                      {attentionLevel}%
                    </div>
                    <p className="text-sm text-muted-foreground">Real-time Attention</p>
                  </div>

                  <Progress
                    value={attentionLevel}
                    className={`h-3 transition-all duration-300 ${
                      attentionLevel < 50 ? 'bg-red-100' :
                      attentionLevel > 80 ? 'bg-green-100' : ''
                    }`}
                  />

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Eye Tracking:</span>
                      <Badge variant={isEyeTrackingActive ? "default" : "secondary"} size="sm">
                        {isEyeTrackingActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span>Looking at Screen:</span>
                      <Badge
                        variant={isLookingAtScreen ? "default" : "destructive"}
                        size="sm"
                        className={!isLookingAtScreen ? "animate-pulse" : ""}
                      >
                        {isLookingAtScreen ? "Yes" : "No"}
                      </Badge>
                    </div>

                    {lowAttentionCount > 0 && (
                      <div className="flex items-center justify-between text-sm">
                        <span>Low Attention Count:</span>
                        <Badge variant="destructive" size="sm" className="animate-bounce">
                          {lowAttentionCount}/3
                        </Badge>
                      </div>
                    )}
                  </div>

                  {attentionLevel < 50 && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg animate-pulse">
                      <div className="flex items-center gap-2 text-red-800">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-sm font-medium">Low attention detected!</span>
                      </div>
                      <p className="text-xs text-red-600 mt-1">
                        An attention exercise will start automatically if this continues.
                      </p>
                    </div>
                  )}

                  {!isLookingAtScreen && (
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg animate-pulse">
                      <div className="flex items-center gap-2 text-orange-800">
                        <Eye className="h-4 w-4" />
                        <span className="text-sm font-medium">Please focus on the screen</span>
                      </div>
                      <p className="text-xs text-orange-600 mt-1">
                        Time away: {awayFromScreenTime}s
                        {awayFromScreenTime >= 3 && " (Video will pause soon)"}
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className={`h-5 w-5 ${isCameraEnabled ? 'text-green-600' : 'text-gray-400'}`} />
                  Camera Control
                  {isCameraEnabled && <Badge size="sm" variant="default">ENABLED</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button
                  onClick={enableCamera}
                  className="w-full"
                  disabled={isCameraEnabled}
                >
                  {isCameraEnabled ? "Camera Enabled ✓" : "Enable Real Camera"}
                </Button>

                {isCameraEnabled && (
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center gap-2 text-green-800">
                      <Camera className="h-4 w-4" />
                      <span className="text-sm font-medium">Camera access granted!</span>
                    </div>
                    <p className="text-xs text-green-600 mt-1">
                      Real-time emotion and attention tracking is now active.
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Focus Restoration Videos Modal (25-49% attention) */}
      {showAttentionVideo && attentionLevel >= 25 && attentionLevel < 50 && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-orange-50 to-yellow-50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-orange-100 rounded-full">
                  <Youtube className="h-6 w-6 text-orange-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-orange-800">Focus Restoration</h3>
                  <p className="text-sm text-orange-600">
                    Your attention is moderate. Try these calming videos to restore focus.
                  </p>
                </div>
              </div>
              <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                Focus: {attentionLevel}%
              </Badge>
            </div>

            <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
              {focusRestorationVideos.map((video, index) => (
                <div
                  key={video.id}
                  className="flex gap-4 p-4 border rounded-xl hover:bg-accent/50 transition-all duration-300 cursor-pointer group animate-in slide-in-from-left duration-700"
                  style={{ animationDelay: `${index * 100}ms` }}
                  onClick={() => {
                    window.open(`https://youtube.com/watch?v=${video.id}`, '_blank');
                  }}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-32 h-20 object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-black/20 rounded-lg flex items-center justify-center group-hover:bg-black/40 transition-colors">
                      <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                        <Play className="h-4 w-4 text-white ml-0.5" />
                      </div>
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1 rounded">
                      {video.duration}
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm leading-tight mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                      {video.title}
                    </h4>
                    <p className="text-xs text-muted-foreground mb-1">{video.channel}</p>
                    <p className="text-xs text-muted-foreground">{video.views}</p>
                    <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ExternalLink className="h-3 w-3" />
                      <span className="text-xs">Watch on YouTube</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 border-t bg-orange-50/50">
              <div className="flex items-center justify-between">
                <p className="text-sm text-orange-800">
                  Meditation and calming videos to restore your focus
                </p>
                <Button
                  onClick={() => setShowAttentionVideo(false)}
                  variant="outline"
                  size="sm"
                >
                  Close
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Attention Training Exercise Modal (for very low attention <25%) */}
      {showAttentionVideo && attentionLevel < 25 && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-4xl w-full max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-red-50 to-orange-50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 rounded-full animate-pulse">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-red-800">Attention Alert!</h3>
                  <p className="text-sm text-red-600">
                    Your focus level is below 50%. Let's do a quick attention exercise.
                  </p>
                </div>
              </div>
              <Badge variant="destructive" className="animate-bounce">
                Focus: {attentionLevel}%
              </Badge>
            </div>

            <div className="p-8">
              <div className="text-center space-y-6">
                <div className="relative">
                  <h2 className="text-2xl font-bold mb-2">
                    {attentionVideos[currentAttentionVideo]?.title}
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    {attentionVideos[currentAttentionVideo]?.description}
                  </p>

                  {/* Attention Exercise Animation */}
                  {attentionVideos[currentAttentionVideo]?.type === "eye-exercise" && (
                    <div className="relative h-64 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border-2 border-dashed border-blue-200 flex items-center justify-center overflow-hidden">
                      <div className="absolute inset-0">
                        <div className="w-4 h-4 bg-blue-500 rounded-full absolute animate-ping"
                             style={{
                               animation: "moveAroundScreen 6s infinite linear",
                               transformOrigin: "center"
                             }}>
                        </div>
                        <div className="w-3 h-3 bg-blue-600 rounded-full absolute"
                             style={{
                               animation: "moveAroundScreen 6s infinite linear",
                               transformOrigin: "center"
                             }}>
                        </div>
                      </div>
                      <div className="text-center z-10 bg-white/80 p-4 rounded-lg">
                        <Eye className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                        <p className="font-medium text-blue-800">Follow the moving dot with your eyes</p>
                      </div>
                    </div>
                  )}

                  {attentionVideos[currentAttentionVideo]?.type === "breathing" && (
                    <div className="relative h-64 bg-gradient-to-br from-green-50 to-teal-50 rounded-xl border-2 border-dashed border-green-200 flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-24 h-24 bg-green-400 rounded-full mx-auto mb-4 animate-pulse"
                             style={{
                               animation: "breathe 4s infinite ease-in-out"
                             }}>
                        </div>
                        <div className="space-y-2">
                          <p className="font-medium text-green-800">Breathe in... Breathe out...</p>
                          <p className="text-sm text-green-600">Sync your breathing with the circle</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {attentionVideos[currentAttentionVideo]?.type === "visual-tracking" && (
                    <div className="relative h-64 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-dashed border-purple-200 flex items-center justify-center overflow-hidden">
                      <div className="absolute inset-0">
                        <div className="w-6 h-6 bg-purple-500 rounded-full absolute"
                             style={{
                               animation: "zigzag 8s infinite linear"
                             }}>
                        </div>
                        <div className="w-4 h-4 bg-pink-500 rounded-square absolute"
                             style={{
                               animation: "circle 10s infinite linear"
                             }}>
                        </div>
                      </div>
                      <div className="text-center z-10 bg-white/80 p-4 rounded-lg">
                        <Target className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                        <p className="font-medium text-purple-800">Track the moving shapes</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-center gap-4">
                  <Button
                    onClick={() => {
                      setShowAttentionVideo(false);
                      setLowAttentionCount(0);
                    }}
                    variant="outline"
                  >
                    Skip Exercise
                  </Button>
                  <Button
                    onClick={() => {
                      setCurrentAttentionVideo((prev) => (prev + 1) % attentionVideos.length);
                    }}
                    className="gap-2"
                  >
                    <Play className="h-4 w-4" />
                    Next Exercise
                  </Button>
                </div>

                <div className="text-xs text-muted-foreground">
                  {isLookingAtScreen ? (
                    <span className="text-green-600">✓ You're focused on the screen</span>
                  ) : (
                    <span className="text-red-600 animate-pulse">⚠ Please look at the screen</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Interest-Based YouTube Video Suggestions Modal */}
      {showVideoSuggestions && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between p-6 border-b bg-red-50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 rounded-full">
                  <Youtube className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-red-800">Critical Attention Alert!</h3>
                  <p className="text-sm text-red-600">
                    Attention below 25% - Here are concentration-improving videos to help you focus
                  </p>
                </div>
              </div>
              <div className="text-right">
                <Badge variant="destructive" className="mb-2">Attention: {attentionLevel}%</Badge>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowVideoSuggestions(false)}
                  className="rounded-full"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>
            </div>

            <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
              {getConcentrationVideos().map((video, index) => (
                <div
                  key={video.id}
                  className="flex gap-4 p-4 border rounded-xl hover:bg-accent/50 transition-all duration-300 cursor-pointer group animate-in slide-in-from-left duration-700"
                  style={{ animationDelay: `${index * 100}ms` }}
                  onClick={() => {
                    window.open(`https://youtube.com/watch?v=${video.id}`, '_blank');
                  }}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-32 h-20 object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-black/20 rounded-lg flex items-center justify-center group-hover:bg-black/40 transition-colors">
                      <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                        <Play className="h-4 w-4 text-white ml-0.5" />
                      </div>
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1 rounded">
                      {video.duration}
                    </div>
                  </div>
                  
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm leading-tight mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                      {video.title}
                    </h4>
                    <p className="text-xs text-muted-foreground mb-1">{video.channel}</p>
                    <p className="text-xs text-muted-foreground">{video.views}</p>
                    <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ExternalLink className="h-3 w-3" />
                      <span className="text-xs">Watch on YouTube</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <div className="p-6 border-t bg-red-50/50">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-red-800 font-medium">
                    Concentration-improving videos to restore focus and attention
                  </p>
                  <p className="text-xs text-red-600">
                    Quick exercises designed to boost your concentration and mental clarity
                  </p>
                </div>
                <Button
                  onClick={() => setShowVideoSuggestions(false)}
                  variant="outline"
                  size="sm"
                  className="border-red-200"
                >
                  Maybe Later
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
