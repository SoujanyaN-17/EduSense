import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  Brain, Eye, Camera, BookOpen, Trophy, Clock, Target,
  Play, ChevronRight, Award, CheckCircle, AlertTriangle,
  TrendingUp, Calendar, Users, Star, Lock, Unlock, GraduationCap,
  Settings, LogOut
} from "lucide-react";

interface UserProfile {
  personalInfo: {
    fullName: string;
    age: string;
    grade: string;
    learningGoals: string[];
  };
  academicInfo: {
    subjects: string[];
    difficultyLevel: string;
    studyTime: string;
  };
  preferences: {
    cameraConsent: boolean;
    attentionTracking: boolean;
  };
}

interface Course {
  id: string;
  title: string;
  subject: string;
  description: string;
  duration: string;
  difficulty: string;
  progress: number;
  totalChapters: number;
  completedChapters: number;
  nextCheckpoint: number;
  isLocked: boolean;
  prerequisites?: string[];
  thumbnail: string;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  earned: boolean;
  earnedDate?: string;
}

export default function EnhancedDashboard() {
  const navigate = useNavigate();
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [currentAttention, setCurrentAttention] = useState(78);
  const [isLookingAtScreen, setIsLookingAtScreen] = useState(true);
  const [isCameraEnabled, setIsCameraEnabled] = useState(false);

  // Load user profile from localStorage
  useEffect(() => {
    const profile = localStorage.getItem("neurolearn_user_profile");
    if (profile) {
      setUserProfile(JSON.parse(profile));
    }

    // Simulate attention tracking based on screen focus
    const interval = setInterval(() => {
      const isLooking = Math.random() > 0.1; // 90% chance of looking at screen
      setIsLookingAtScreen(isLooking);

      // Focus percentage should be high when looking at screen, low when not
      if (isLooking) {
        setCurrentAttention(Math.floor(Math.random() * 30) + 70); // 70-100% when focused
      } else {
        setCurrentAttention(Math.floor(Math.random() * 40) + 10); // 10-50% when not looking
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  // Generate personalized courses based on user profile with dynamic progress
  const getPersonalizedCourses = (): Course[] => {
    if (!userProfile) return [];

    const getActualProgress = (courseId: string) => {
      const savedProgress = localStorage.getItem(`progress_${courseId}`);
      if (savedProgress) {
        const progress = JSON.parse(savedProgress);
        return {
          progress: Math.min(Math.round((progress.totalWatchTime / 1800) * 100), 100), // 30 min = 100%
          completedChapters: Math.floor(progress.totalWatchTime / 600), // 10 min per chapter
          nextCheckpoint: Math.floor(progress.totalWatchTime / 600) + 1
        };
      }
      return { progress: 0, completedChapters: 0, nextCheckpoint: 1 };
    };

    const baseCoursesMap: Record<string, Course[]> = {
      "Reading & Writing": [
        {
          id: "reading-basics",
          title: "Reading Adventures",
          subject: "Reading & Writing",
          description: "Learn to read with fun stories and characters",
          duration: "2 weeks",
          difficulty: "Beginner",
          ...getActualProgress("reading-basics"),
          totalChapters: 8,
          isLocked: false,
          thumbnail: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300&h=200&fit=crop"
        }
      ],
      "Basic Math": [
        {
          id: "math-fun",
          title: "Math Magic",
          subject: "Basic Math",
          description: "Discover the magic of numbers with interactive games",
          duration: "3 weeks",
          difficulty: "Beginner",
          ...getActualProgress("math-fun"),
          totalChapters: 12,
          isLocked: false,
          thumbnail: "https://images.unsplash.com/photo-1518133910546-b6c2fb7d79e3?w=300&h=200&fit=crop"
        }
      ],
      "English": [
        {
          id: "english-mastery",
          title: "English Language Mastery",
          subject: "English",
          description: "Comprehensive English language skills development",
          duration: "8 weeks",
          difficulty: "Intermediate",
          ...getActualProgress("english-mastery"),
          totalChapters: 16,
          isLocked: false,
          thumbnail: "https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=300&h=200&fit=crop"
        }
      ],
      "Mathematics": [
        {
          id: "algebra-foundations",
          title: "Algebra Foundations",
          subject: "Mathematics",
          description: "Master the fundamentals of algebraic thinking",
          duration: "6 weeks",
          difficulty: "Intermediate",
          ...getActualProgress("algebra-foundations"),
          totalChapters: 10,
          isLocked: false,
          thumbnail: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=300&h=200&fit=crop"
        },
        {
          id: "geometry-advanced",
          title: "Advanced Geometry",
          subject: "Mathematics",
          description: "Explore complex geometric concepts and proofs",
          duration: "8 weeks",
          difficulty: "Advanced",
          ...getActualProgress("geometry-advanced"),
          totalChapters: 12,
          isLocked: getActualProgress("algebra-foundations").progress < 80,
          prerequisites: ["algebra-foundations"],
          thumbnail: "https://images.unsplash.com/photo-1596495577886-d920f1fb7238?w=300&h=200&fit=crop"
        }
      ],
      "Computer Science": [
        {
          id: "programming-basics",
          title: "Programming Fundamentals",
          subject: "Computer Science",
          description: "Learn programming concepts with hands-on coding",
          duration: "10 weeks",
          difficulty: "Beginner",
          ...getActualProgress("programming-basics"),
          totalChapters: 20,
          isLocked: false,
          thumbnail: "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?w=300&h=200&fit=crop"
        }
      ],
      "Science": [
        {
          id: "biology-intro",
          title: "Introduction to Biology",
          subject: "Science",
          description: "Explore the fascinating world of living organisms",
          duration: "12 weeks",
          difficulty: "Intermediate",
          ...getActualProgress("biology-intro"),
          totalChapters: 15,
          isLocked: false,
          thumbnail: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=300&h=200&fit=crop"
        }
      ]
    };

    // Filter courses based on user's selected subjects
    const userCourses: Course[] = [];
    userProfile.academicInfo.subjects.forEach(subject => {
      if (baseCoursesMap[subject]) {
        userCourses.push(...baseCoursesMap[subject]);
      }
    });

    return userCourses;
  };

  const achievements: Achievement[] = [
    {
      id: "first-lesson",
      title: "First Steps",
      description: "Completed your first lesson",
      icon: "🎯",
      earned: true,
      earnedDate: "2024-01-15"
    },
    {
      id: "week-streak",
      title: "Week Warrior",
      description: "Studied for 7 days in a row",
      icon: "🔥",
      earned: true,
      earnedDate: "2024-01-20"
    },
    {
      id: "attention-master",
      title: "Focus Master",
      description: "Maintained 90%+ attention for a full lesson",
      icon: "👁️",
      earned: false
    },
    {
      id: "checkpoint-champion",
      title: "Checkpoint Champion",
      description: "Passed 5 checkpoints with perfect scores",
      icon: "🏆",
      earned: false
    }
  ];

  const enableCamera = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      setIsCameraEnabled(true);
    } catch (error) {
      console.error("Camera access denied:", error);
    }
  };

  const getAttentionColor = () => {
    if (currentAttention >= 80) return "text-green-600";
    if (currentAttention >= 50) return "text-yellow-600";
    return "text-red-600";
  };

  if (!userProfile) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100 flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader className="text-center">
            <Brain className="h-12 w-12 text-primary mx-auto mb-4" />
            <CardTitle>Welcome to NeuroLearn AI</CardTitle>
            <CardDescription>Complete your profile setup to get started</CardDescription>
          </CardHeader>
          <CardContent>
            <Button onClick={() => navigate("/onboarding")} className="w-full">
              Complete Setup
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const courses = getPersonalizedCourses();

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <Brain className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                  NeuroLearn AI
                </h1>
                <p className="text-sm text-muted-foreground">Welcome back, {userProfile.personalInfo.fullName.split(' ')[0]}!</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Attention indicator */}
              <div className="flex items-center gap-2 px-3 py-2 bg-background/60 rounded-lg border">
                <Eye className={`h-4 w-4 ${getAttentionColor()}`} />
                <span className={`text-sm font-medium ${getAttentionColor()}`}>
                  {currentAttention}%
                </span>
                <Badge variant={isLookingAtScreen ? "default" : "destructive"} size="sm">
                  {isLookingAtScreen ? "Focused" : "Away"}
                </Badge>
              </div>

              <Button variant="outline" size="sm" onClick={() => navigate("/settings")} className="gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </Button>

              <Avatar>
                <AvatarFallback className="bg-primary/10 text-primary">
                  {userProfile.personalInfo.fullName.split(' ').map(n => n[0]).join('').toUpperCase()}
                </AvatarFallback>
              </Avatar>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Profile Summary */}
        <div className="grid md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Grade Level</p>
                  <p className="text-2xl font-bold">{userProfile.personalInfo.grade}</p>
                </div>
                <GraduationCap className="h-8 w-8 text-primary" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Courses Enrolled</p>
                  <p className="text-2xl font-bold">{courses.length}</p>
                </div>
                <BookOpen className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Achievements</p>
                  <p className="text-2xl font-bold">{achievements.filter(a => a.earned).length}</p>
                </div>
                <Trophy className="h-8 w-8 text-yellow-600" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Study Streak</p>
                  <p className="text-2xl font-bold">7 days</p>
                </div>
                <Calendar className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="courses" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="courses">My Courses</TabsTrigger>
            <TabsTrigger value="progress">Progress</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="settings">Camera & AI</TabsTrigger>
          </TabsList>

          {/* Courses Tab */}
          <TabsContent value="courses" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">Your Learning Path</h2>
              <Badge variant="outline">{userProfile.academicInfo.difficultyLevel} Level</Badge>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {courses.map((course) => (
                <Card key={course.id} className={`transition-all hover:shadow-lg ${course.isLocked ? 'opacity-60' : 'cursor-pointer hover:scale-105'}`}>
                  <div className="relative">
                    <img 
                      src={course.thumbnail} 
                      alt={course.title}
                      className="w-full h-40 object-cover rounded-t-lg"
                    />
                    {course.isLocked && (
                      <div className="absolute inset-0 bg-black/50 rounded-t-lg flex items-center justify-center">
                        <Lock className="h-8 w-8 text-white" />
                      </div>
                    )}
                    <Badge 
                      variant={course.difficulty === 'Beginner' ? 'default' : course.difficulty === 'Intermediate' ? 'secondary' : 'destructive'}
                      className="absolute top-2 right-2"
                    >
                      {course.difficulty}
                    </Badge>
                  </div>
                  
                  <CardHeader>
                    <CardTitle className="text-lg flex items-center justify-between">
                      {course.title}
                      {course.isLocked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4 text-green-600" />}
                    </CardTitle>
                    <CardDescription>{course.description}</CardDescription>
                  </CardHeader>
                  
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">{course.completedChapters}/{course.totalChapters} chapters</span>
                      </div>
                      
                      <Progress value={course.progress} className="h-2" />
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <Clock className="h-4 w-4" />
                          {course.duration}
                        </div>
                        {course.nextCheckpoint && (
                          <Badge variant="outline" size="sm">
                            Next: Chapter {course.nextCheckpoint}
                          </Badge>
                        )}
                      </div>

                      {course.prerequisites && course.isLocked && (
                        <div className="text-xs text-muted-foreground">
                          <p>Prerequisites: Complete {course.prerequisites.join(", ")}</p>
                        </div>
                      )}
                      
                      <Button
                        className="w-full gap-2"
                        disabled={course.isLocked}
                        onClick={() => navigate(`/improved-learning/${course.id}`)}
                      >
                        {course.progress > 0 ? "Continue" : "Start Course"}
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Progress Tab */}
          <TabsContent value="progress" className="space-y-6">
            <h2 className="text-2xl font-bold">Learning Analytics</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Weekly Progress
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {userProfile.academicInfo.subjects.slice(0, 3).map((subject, index) => (
                      <div key={subject} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">{subject}</span>
                          <span className="text-sm text-muted-foreground">{Math.floor(Math.random() * 50) + 50}%</span>
                        </div>
                        <Progress value={Math.floor(Math.random() * 50) + 50} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Learning Goals
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {userProfile.personalInfo.learningGoals.slice(0, 4).map((goal, index) => (
                      <div key={goal} className="flex items-center gap-3">
                        <CheckCircle className={`h-4 w-4 ${index < 2 ? 'text-green-600' : 'text-muted-foreground'}`} />
                        <span className={`text-sm ${index < 2 ? 'line-through text-muted-foreground' : ''}`}>
                          {goal}
                        </span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Attention Analytics</CardTitle>
                <CardDescription>Your focus patterns during learning sessions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Average Attention Level</span>
                    <Badge variant={currentAttention >= 70 ? "default" : "secondary"}>
                      {currentAttention}%
                    </Badge>
                  </div>
                  <Progress value={currentAttention} className="h-3" />
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-green-600">85%</p>
                      <p className="text-xs text-muted-foreground">Best Session</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">23</p>
                      <p className="text-xs text-muted-foreground">Sessions</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-purple-600">4.2h</p>
                      <p className="text-xs text-muted-foreground">Total Time</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-6">
            <h2 className="text-2xl font-bold">Achievements & Badges</h2>
            
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {achievements.map((achievement) => (
                <Card key={achievement.id} className={`transition-all ${achievement.earned ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200' : 'opacity-60'}`}>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-3">{achievement.icon}</div>
                    <h3 className="font-semibold mb-2">{achievement.title}</h3>
                    <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
                    {achievement.earned ? (
                      <Badge variant="default" className="bg-yellow-600">
                        Earned {achievement.earnedDate}
                      </Badge>
                    ) : (
                      <Badge variant="outline">
                        Not Earned Yet
                      </Badge>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <h2 className="text-2xl font-bold">Camera & AI Settings</h2>
            
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Camera className={`h-5 w-5 ${isCameraEnabled ? 'text-green-600' : 'text-gray-400'}`} />
                    Camera Status
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Camera Access</span>
                    <Badge variant={isCameraEnabled ? "default" : "secondary"}>
                      {isCameraEnabled ? "Enabled" : "Disabled"}
                    </Badge>
                  </div>
                  
                  {!isCameraEnabled && (
                    <Button onClick={enableCamera} className="w-full">
                      Enable Camera
                    </Button>
                  )}
                  
                  {isCameraEnabled && (
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Real-time Attention</span>
                        <Badge variant="default">{currentAttention}%</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm">Looking at Screen</span>
                        <Badge variant={isLookingAtScreen ? "default" : "destructive"}>
                          {isLookingAtScreen ? "Yes" : "No"}
                        </Badge>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Brain className="h-5 w-5 text-primary" />
                    AI Features
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Emotion Detection</span>
                      <Badge variant={userProfile.preferences.cameraConsent ? "default" : "secondary"}>
                        {userProfile.preferences.cameraConsent ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Attention Tracking</span>
                      <Badge variant={userProfile.preferences.attentionTracking ? "default" : "secondary"}>
                        {userProfile.preferences.attentionTracking ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Adaptive Content</span>
                      <Badge variant="default">Active</Badge>
                    </div>
                  </div>

                  {currentAttention < 50 && (
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <div className="flex items-center gap-2 text-orange-800 mb-1">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-sm font-medium">Attention Alert</span>
                      </div>
                      <p className="text-xs text-orange-600">
                        Your attention is below optimal. Consider taking a break or trying a focus exercise.
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
