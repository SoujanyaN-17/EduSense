import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Separator } from "@/components/ui/separator";
import { Brain, Camera, Eye, Heart, ChevronLeft, Shield, Bell, Palette, User, Save, Download } from "lucide-react";

export default function Settings() {
  // Camera and tracking settings
  const [webcamEnabled, setWebcamEnabled] = useState(true);
  const [emotionTracking, setEmotionTracking] = useState(true);
  const [attentionTracking, setAttentionTracking] = useState(true);
  const [dataRetention, setDataRetention] = useState("30days");
  
  // Learning preferences  
  const [learningStyle, setLearningStyle] = useState("adaptive");
  const [sessionDuration, setSessionDuration] = useState([45]);
  const [difficultyPref, setDifficultyPref] = useState("adaptive");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  
  // Privacy settings
  const [dataSharing, setDataSharing] = useState(false);
  const [analytics, setAnalytics] = useState(true);
  const [personalizedAds, setPersonalizedAds] = useState(false);
  
  // Theme and accessibility
  const [theme, setTheme] = useState("system");
  const [fontSize, setFontSize] = useState([16]);
  const [reducedMotion, setReducedMotion] = useState(false);

  const saveSettings = () => {
    // Here you would save settings to backend
    console.log("Settings saved!");
  };

  const exportData = () => {
    // Here you would export user data
    console.log("Exporting user data...");
  };

  const deleteAccount = () => {
    // Here you would handle account deletion
    console.log("Account deletion requested");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="ghost" size="sm" className="gap-2">
                  <ChevronLeft className="h-4 w-4" />
                  Back to Dashboard
                </Button>
              </Link>
              <div>
                <h1 className="text-2xl font-bold">Settings & Preferences</h1>
                <p className="text-sm text-muted-foreground">Customize your learning experience</p>
              </div>
            </div>
            <Button onClick={saveSettings} className="gap-2">
              <Save className="h-4 w-4" />
              Save Changes
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Settings */}
          <div className="lg:col-span-2 space-y-8">
            {/* AI Tracking Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Camera className="h-5 w-5" />
                  AI Tracking & Monitoring
                </CardTitle>
                <CardDescription>
                  Control how NeuroLearn AI monitors your learning sessions
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="font-medium">Webcam Access</h4>
                      <p className="text-sm text-muted-foreground">
                        Allow camera access for emotion and attention tracking
                      </p>
                    </div>
                    <Switch 
                      checked={webcamEnabled} 
                      onCheckedChange={setWebcamEnabled}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="font-medium">Emotion Detection</h4>
                      <p className="text-sm text-muted-foreground">
                        Analyze facial expressions to understand your emotional state
                      </p>
                    </div>
                    <Switch 
                      checked={emotionTracking} 
                      onCheckedChange={setEmotionTracking}
                      disabled={!webcamEnabled}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="flex items-center justify-between">
                    <div className="space-y-1">
                      <h4 className="font-medium">Attention Tracking</h4>
                      <p className="text-sm text-muted-foreground">
                        Monitor eye movement and focus patterns
                      </p>
                    </div>
                    <Switch 
                      checked={attentionTracking} 
                      onCheckedChange={setAttentionTracking}
                      disabled={!webcamEnabled}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-3">
                    <h4 className="font-medium">Data Retention Period</h4>
                    <Select value={dataRetention} onValueChange={setDataRetention}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="7days">7 days</SelectItem>
                        <SelectItem value="30days">30 days</SelectItem>
                        <SelectItem value="90days">90 days</SelectItem>
                        <SelectItem value="1year">1 year</SelectItem>
                        <SelectItem value="indefinite">Indefinite</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-sm text-muted-foreground">
                      How long to keep your emotion and attention data
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Learning Preferences */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  Learning Preferences
                </CardTitle>
                <CardDescription>
                  Customize how content is delivered based on your learning style
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <h4 className="font-medium">Preferred Learning Style</h4>
                  <Select value={learningStyle} onValueChange={setLearningStyle}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="adaptive">Adaptive (AI decides)</SelectItem>
                      <SelectItem value="visual">Visual Learning</SelectItem>
                      <SelectItem value="auditory">Auditory Learning</SelectItem>
                      <SelectItem value="kinesthetic">Kinesthetic Learning</SelectItem>
                      <SelectItem value="reading">Reading/Writing</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium">Session Duration</h4>
                  <div className="px-3">
                    <Slider
                      value={sessionDuration}
                      onValueChange={setSessionDuration}
                      max={120}
                      min={15}
                      step={15}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-muted-foreground mt-1">
                      <span>15 min</span>
                      <span className="font-medium">{sessionDuration[0]} minutes</span>
                      <span>2 hours</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium">Content Difficulty</h4>
                  <Select value={difficultyPref} onValueChange={setDifficultyPref}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="adaptive">Adaptive (Based on performance)</SelectItem>
                      <SelectItem value="beginner">Always Beginner</SelectItem>
                      <SelectItem value="intermediate">Always Intermediate</SelectItem>
                      <SelectItem value="advanced">Always Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h4 className="font-medium">Learning Reminders</h4>
                    <p className="text-sm text-muted-foreground">
                      Get notified about scheduled learning sessions
                    </p>
                  </div>
                  <Switch 
                    checked={notificationsEnabled} 
                    onCheckedChange={setNotificationsEnabled}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Privacy & Data */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Privacy & Data Control
                </CardTitle>
                <CardDescription>
                  Manage how your data is used and shared
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h4 className="font-medium">Anonymous Data Sharing</h4>
                    <p className="text-sm text-muted-foreground">
                      Help improve AI models by sharing anonymized learning data
                    </p>
                  </div>
                  <Switch 
                    checked={dataSharing} 
                    onCheckedChange={setDataSharing}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h4 className="font-medium">Learning Analytics</h4>
                    <p className="text-sm text-muted-foreground">
                      Allow detailed analytics to improve your learning experience
                    </p>
                  </div>
                  <Switch 
                    checked={analytics} 
                    onCheckedChange={setAnalytics}
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h4 className="font-medium">Personalized Recommendations</h4>
                    <p className="text-sm text-muted-foreground">
                      Use your data for personalized course recommendations
                    </p>
                  </div>
                  <Switch 
                    checked={personalizedAds} 
                    onCheckedChange={setPersonalizedAds}
                  />
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium">Data Export & Deletion</h4>
                  <div className="flex gap-3">
                    <Button onClick={exportData} variant="outline" className="gap-2">
                      <Download className="h-4 w-4" />
                      Export My Data
                    </Button>
                    <Button onClick={deleteAccount} variant="destructive" className="gap-2">
                      Delete Account
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Export all your learning data or permanently delete your account
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Accessibility */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="h-5 w-5" />
                  Theme & Accessibility
                </CardTitle>
                <CardDescription>
                  Customize the appearance and accessibility features
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <h4 className="font-medium">Theme</h4>
                  <Select value={theme} onValueChange={setTheme}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <h4 className="font-medium">Font Size</h4>
                  <div className="px-3">
                    <Slider
                      value={fontSize}
                      onValueChange={setFontSize}
                      max={24}
                      min={12}
                      step={2}
                      className="w-full"
                    />
                    <div className="flex justify-between text-sm text-muted-foreground mt-1">
                      <span>Small</span>
                      <span className="font-medium">{fontSize[0]}px</span>
                      <span>Large</span>
                    </div>
                  </div>
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h4 className="font-medium">Reduced Motion</h4>
                    <p className="text-sm text-muted-foreground">
                      Minimize animations and motion effects
                    </p>
                  </div>
                  <Switch 
                    checked={reducedMotion} 
                    onCheckedChange={setReducedMotion}
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Profile Summary */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Profile Summary
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center space-y-2">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                    <User className="h-8 w-8 text-primary" />
                  </div>
                  <h3 className="font-semibold">Alex Johnson</h3>
                  <p className="text-sm text-muted-foreground">alex.johnson@email.com</p>
                </div>
                
                <Separator />
                
                <div className="space-y-3">
                  <div className="flex justify-between text-sm">
                    <span>Member since</span>
                    <span>Jan 2024</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Courses completed</span>
                    <span>12</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Total learning time</span>
                    <span>68h 24m</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Current streak</span>
                    <span>12 days</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Current Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Webcam Tracking</span>
                  <Badge variant={webcamEnabled ? "default" : "secondary"}>
                    {webcamEnabled ? "Enabled" : "Disabled"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Emotion Detection</span>
                  <Badge variant={emotionTracking ? "default" : "secondary"}>
                    {emotionTracking ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Learning Style</span>
                  <Badge variant="outline">
                    {learningStyle === "adaptive" ? "Adaptive" : learningStyle}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Session Length</span>
                  <span>{sessionDuration[0]} min</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5" />
                  Privacy Status
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span>Data Sharing</span>
                  <Badge variant={dataSharing ? "destructive" : "default"}>
                    {dataSharing ? "Enabled" : "Disabled"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Analytics</span>
                  <Badge variant={analytics ? "default" : "secondary"}>
                    {analytics ? "Active" : "Inactive"}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Data Retention</span>
                  <span className="capitalize">{dataRetention.replace("days", " days")}</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
