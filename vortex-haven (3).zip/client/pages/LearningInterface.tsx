import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
// @ts-ignore
import * as webgazer from "webgazer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Brain, Eye, Play, Pause, SkipForward, SkipBack, BookOpen, 
  CheckCircle, Clock, Trophy, AlertTriangle, Target, Lightbulb,
  Camera, Mic, Volume2, Settings, Home, ArrowLeft, Award
} from "lucide-react";

interface Checkpoint {
  id: number;
  title: string;
  type: "quiz" | "exercise" | "project";
  questions?: Question[];
  exercise?: Exercise;
  requiredScore: number;
  passed: boolean;
  score?: number;
}

interface Question {
  id: string;
  type: "multiple-choice" | "true-false" | "text" | "code";
  question: string;
  options?: string[];
  correctAnswer: string | number;
  explanation: string;
}

interface Exercise {
  id: string;
  title: string;
  description: string;
  instructions: string[];
  videoUrl?: string;
  duration: number;
}

interface Chapter {
  id: number;
  title: string;
  content: string;
  videoUrl: string;
  duration: number;
  checkpoint?: Checkpoint;
  completed: boolean;
}

interface Course {
  id: string;
  title: string;
  subject: string;
  chapters: Chapter[];
  totalDuration: number;
}

export default function LearningInterface() {
  const { courseId } = useParams();
  const navigate = useNavigate();

  // Video and content state
  const [currentChapter, setCurrentChapter] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);
  const [isVideoCompleted, setIsVideoCompleted] = useState(false);

  // Attention and camera state
  const [currentAttention, setCurrentAttention] = useState(85);
  const [isLookingAtScreen, setIsLookingAtScreen] = useState(true);
  const [awayFromScreenTime, setAwayFromScreenTime] = useState(0);
  const [showConcentrationVideos, setShowConcentrationVideos] = useState(false);
  const [isCameraEnabled, setIsCameraEnabled] = useState(false);

  // Checkpoint and quiz state
  const [showCheckpoint, setShowCheckpoint] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [checkpointScore, setCheckpointScore] = useState(0);
  const [showCheckpointResults, setShowCheckpointResults] = useState(false);

  // Concentration videos for when attention is low
  const concentrationVideos = [
    {
      id: "focus-1",
      title: "5-Minute Focus Breathing",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=320&h=180&fit=crop",
      duration: "5:00",
      description: "Guided breathing exercise to restore concentration"
    },
    {
      id: "focus-2",
      title: "Visual Focus Training",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=320&h=180&fit=crop",
      duration: "3:00",
      description: "Eye movement exercises to improve visual attention"
    },
    {
      id: "focus-3",
      title: "Quick Meditation Break",
      thumbnail: "https://images.unsplash.com/photo-1540979388789-6cee28a1cdc9?w=320&h=180&fit=crop",
      duration: "7:00",
      description: "Short mindfulness meditation for mental clarity"
    }
  ];

  // Sample course data (would normally come from API)
  const course: Course = {
    id: courseId || "programming-basics",
    title: "Programming Fundamentals",
    subject: "Computer Science",
    totalDuration: 1200,
    chapters: [
      {
        id: 1,
        title: "Introduction to Programming",
        content: `
        # Welcome to Programming!

        Programming is the art of telling computers what to do through code. In this chapter, you'll learn:

        ## What is Programming?
        Programming is a way to communicate with computers using special languages that both humans and machines can understand.

        ## Why Learn Programming?
        - Solve real-world problems
        - Create websites and apps
        - Automate repetitive tasks
        - Think logically and systematically

        ## Basic Concepts
        1. **Variables**: Store information
        2. **Functions**: Reusable blocks of code
        3. **Loops**: Repeat actions
        4. **Conditions**: Make decisions

        Let's start your programming journey!
        `,
        videoUrl: "intro-programming",
        duration: 15,
        completed: false,
        checkpoint: {
          id: 1,
          title: "Introduction Quiz",
          type: "quiz",
          requiredScore: 70,
          passed: false,
          questions: [
            {
              id: "q1",
              type: "multiple-choice",
              question: "What is programming?",
              options: [
                "A way to communicate with computers",
                "A type of math",
                "A form of art",
                "A cooking technique"
              ],
              correctAnswer: 0,
              explanation: "Programming is indeed a way to communicate with computers using special languages."
            },
            {
              id: "q2",
              type: "true-false",
              question: "Variables are used to store information in programming.",
              options: ["True", "False"],
              correctAnswer: 0,
              explanation: "Variables are containers that hold data values in programming."
            },
            {
              id: "q3",
              type: "multiple-choice",
              question: "Which of these is NOT a basic programming concept?",
              options: ["Variables", "Functions", "Dancing", "Loops"],
              correctAnswer: 2,
              explanation: "Dancing is not a programming concept. Variables, functions, and loops are fundamental concepts."
            }
          ]
        }
      },
      {
        id: 2,
        title: "Variables and Data Types",
        content: `
        # Variables and Data Types

        Variables are like containers that store data. Think of them as labeled boxes where you can put different types of information.

        ## What are Variables?
        A variable is a name given to a memory location where we can store data.

        ## Common Data Types
        1. **Numbers**: 42, 3.14
        2. **Text (Strings)**: "Hello World"
        3. **True/False (Boolean)**: true or false
        4. **Lists**: [1, 2, 3, 4]

        ## Creating Variables
        \`\`\`
        let age = 25;
        let name = "Alex";
        let isStudent = true;
        \`\`\`

        Variables make your programs flexible and powerful!
        `,
        videoUrl: "variables-datatypes",
        duration: 20,
        completed: false,
        checkpoint: {
          id: 2,
          title: "Variables Checkpoint",
          type: "quiz",
          requiredScore: 75,
          passed: false,
          questions: [
            {
              id: "q1",
              type: "text",
              question: "What would you store in a variable called 'studentName'?",
              correctAnswer: "name",
              explanation: "A variable called 'studentName' would logically store a student's name (text/string data)."
            },
            {
              id: "q2",
              type: "multiple-choice",
              question: "Which is the correct way to create a variable in JavaScript?",
              options: [
                "variable age = 25",
                "let age = 25",
                "create age = 25",
                "make age = 25"
              ],
              correctAnswer: 1,
              explanation: "In JavaScript, 'let' is the correct keyword to declare variables."
            }
          ]
        }
      },
      {
        id: 3,
        title: "Functions and Methods",
        content: `
        # Functions and Methods

        Functions are reusable blocks of code that perform specific tasks. They're like recipes in programming!

        ## What are Functions?
        Functions are self-contained blocks of code that:
        - Take inputs (parameters)
        - Process the data
        - Return outputs

        ## Why Use Functions?
        - **Reusability**: Write once, use many times
        - **Organization**: Keep code neat and organized
        - **Testing**: Easier to test small pieces

        ## Creating Functions
        \`\`\`
        function greetUser(name) {
            return "Hello, " + name + "!";
        }
        
        // Using the function
        let message = greetUser("Alex");
        \`\`\`

        Functions make programming more efficient and organized!
        `,
        videoUrl: "functions-methods",
        duration: 25,
        completed: false,
        checkpoint: {
          id: 3,
          title: "Functions Practice",
          type: "exercise",
          requiredScore: 80,
          passed: false,
          exercise: {
            id: "func-exercise",
            title: "Create Your First Function",
            description: "Write a function that calculates the area of a rectangle",
            instructions: [
              "Create a function called 'calculateArea'",
              "It should take two parameters: width and height",
              "Return the result of width × height",
              "Test your function with different values"
            ],
            duration: 300
          }
        }
      }
    ]
  };

  // Attention monitoring
  useEffect(() => {
    const interval = setInterval(() => {
      const lookingAway = Math.random() < 0.1;

      // Focus percentage should be based on screen attention
      let attentionScore;
      if (!lookingAway) {
        attentionScore = Math.floor(Math.random() * 30) + 70; // 70-100% when looking at screen
      } else {
        attentionScore = Math.floor(Math.random() * 40) + 10; // 10-50% when not looking
      }

      setCurrentAttention(attentionScore);
      setIsLookingAtScreen(!lookingAway);

      const newAttention = attentionScore; // Use the calculated attention score

      // Handle looking away from screen
      if (lookingAway && isVideoPlaying) {
        setAwayFromScreenTime(prev => {
          const newTime = prev + 1;
          if (newTime >= 3) {
            setIsVideoPlaying(false);
            setAwayFromScreenTime(0);
          }
          return newTime;
        });
      } else {
        setAwayFromScreenTime(0);
      }

      // Show concentration videos for low attention
      if (newAttention < 40 && !showConcentrationVideos && !showCheckpoint) {
        setShowConcentrationVideos(true);
        if (isVideoPlaying) setIsVideoPlaying(false);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [isVideoPlaying, showConcentrationVideos, showCheckpoint]);

  // Video progress simulation
  useEffect(() => {
    if (isVideoPlaying) {
      const interval = setInterval(() => {
        setVideoProgress(prev => {
          const newProgress = prev + 1;
          if (newProgress >= 100) {
            setIsVideoPlaying(false);
            setIsVideoCompleted(true);
            return 100;
          }
          return newProgress;
        });
      }, 200);

      return () => clearInterval(interval);
    }
  }, [isVideoPlaying]);

  const currentChapterData = course.chapters[currentChapter];

  const handleVideoComplete = () => {
    setIsVideoCompleted(true);
    course.chapters[currentChapter].completed = true;
    
    // Show checkpoint if available
    if (currentChapterData.checkpoint) {
      setShowCheckpoint(true);
    }
  };

  const handleNextChapter = () => {
    if (currentChapter < course.chapters.length - 1) {
      setCurrentChapter(currentChapter + 1);
      setVideoProgress(0);
      setIsVideoCompleted(false);
      setShowCheckpoint(false);
      setShowCheckpointResults(false);
      setCurrentQuestion(0);
      setAnswers({});
    }
  };

  const handlePrevChapter = () => {
    if (currentChapter > 0) {
      setCurrentChapter(currentChapter - 1);
      setVideoProgress(0);
      setIsVideoCompleted(false);
      setShowCheckpoint(false);
      setShowCheckpointResults(false);
    }
  };

  const handleAnswerSubmit = (questionId: string, answer: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const calculateCheckpointScore = () => {
    const checkpoint = currentChapterData.checkpoint;
    if (!checkpoint?.questions) return 0;

    let correct = 0;
    checkpoint.questions.forEach(question => {
      const userAnswer = answers[question.id];
      if (userAnswer === question.correctAnswer) {
        correct++;
      }
    });

    return Math.round((correct / checkpoint.questions.length) * 100);
  };

  const submitCheckpoint = () => {
    const score = calculateCheckpointScore();
    setCheckpointScore(score);
    setShowCheckpointResults(true);
    
    const checkpoint = currentChapterData.checkpoint;
    if (checkpoint && score >= checkpoint.requiredScore) {
      checkpoint.passed = true;
      checkpoint.score = score;
    }
  };

  const enableCamera = async () => {
    try {
      await navigator.mediaDevices.getUserMedia({ video: true });
      setIsCameraEnabled(true);
    } catch (error) {
      console.error("Camera access denied");
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-xl">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">{course.title}</h1>
                  <p className="text-sm text-muted-foreground">
                    Chapter {currentChapter + 1}: {currentChapterData.title}
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Attention Status */}
              <div className="flex items-center gap-2 px-3 py-2 bg-background/60 rounded-lg border">
                <Eye className={`h-4 w-4 ${currentAttention >= 70 ? 'text-green-600' : currentAttention >= 40 ? 'text-yellow-600' : 'text-red-600'}`} />
                <span className={`text-sm font-medium ${currentAttention >= 70 ? 'text-green-600' : currentAttention >= 40 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {currentAttention}%
                </span>
                <Badge variant={isLookingAtScreen ? "default" : "destructive"} size="sm">
                  {isLookingAtScreen ? "Focused" : "Away"}
                </Badge>
              </div>

              <Button variant="outline" size="sm" onClick={() => navigate("/settings")} className="gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </Button>

              <Button variant="outline" size="sm" onClick={enableCamera} disabled={isCameraEnabled}>
                <Camera className={`h-4 w-4 mr-2 ${isCameraEnabled ? 'text-green-600' : ''}`} />
                {isCameraEnabled ? "Camera On" : "Enable Camera"}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-3 space-y-6">
            {/* Video Player */}
            <Card>
              <CardContent className="p-0">
                <div className="relative bg-black rounded-t-lg overflow-hidden aspect-video">
                  {isVideoPlaying ? (
                    <div className="bg-gradient-to-br from-slate-800 to-slate-900 h-full flex flex-col">
                      <div className="flex-1 p-8">
                        <div className="bg-slate-700 rounded-lg p-6 mb-4">
                          <h3 className="text-white text-xl mb-2">{currentChapterData.title}</h3>
                          <div className="text-slate-300 text-sm space-y-2">
                            <p>Learning objective: Understanding core concepts</p>
                            <p>Duration: {currentChapterData.duration} minutes</p>
                            <p>Progress: {videoProgress}%</p>
                          </div>
                        </div>
                        <div className="bg-blue-600 rounded p-4">
                          <p className="text-white font-mono text-sm">
                            // This is where the actual video content would play
                            <br />
                            console.log("Learning programming concepts...");
                          </p>
                        </div>
                      </div>

                      <div className="bg-black/50 p-4">
                        <div className="flex items-center gap-4 text-white text-sm">
                          <span>{Math.floor(videoProgress * currentChapterData.duration / 100)}:{String(Math.floor((videoProgress * currentChapterData.duration / 100) % 1 * 60)).padStart(2, '0')} / {currentChapterData.duration}:00</span>
                          <div className="flex-1 bg-gray-600 h-1 rounded">
                            <div className="bg-red-500 h-1 rounded transition-all duration-200" style={{ width: `${videoProgress}%` }}></div>
                          </div>
                          <span>HD</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Play className="h-10 w-10 ml-1" />
                        </div>
                        <p className="text-xl font-medium mb-2">{currentChapterData.title}</p>
                        <p className="text-sm opacity-75 mb-4">Chapter {currentChapter + 1} • {currentChapterData.duration} minutes</p>
                      </div>
                    </div>
                  )}

                  {/* Attention Warning Overlay */}
                  {!isLookingAtScreen && isVideoPlaying && (
                    <div className="absolute inset-0 bg-red-900/80 flex items-center justify-center">
                      <div className="text-center text-white">
                        <AlertTriangle className="h-12 w-12 mx-auto mb-4 animate-bounce" />
                        <p className="text-xl font-bold mb-2">Please Look at Screen</p>
                        <p className="text-sm">Video will pause in {Math.max(0, 3 - awayFromScreenTime)}s</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Button
                        onClick={() => setIsVideoPlaying(!isVideoPlaying)}
                        className="gap-2"
                        disabled={videoProgress >= 100}
                      >
                        {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        {isVideoPlaying ? "Pause" : videoProgress >= 100 ? "Completed" : "Play"}
                      </Button>

                      {videoProgress >= 100 && (
                        <Button
                          onClick={handleVideoComplete}
                          variant="outline"
                          className="gap-2"
                        >
                          <CheckCircle className="h-4 w-4" />
                          Mark Complete
                        </Button>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <Button variant="outline" size="sm" onClick={handlePrevChapter} disabled={currentChapter === 0}>
                        <SkipBack className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={handleNextChapter} disabled={currentChapter === course.chapters.length - 1}>
                        <SkipForward className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>

                  <Progress value={videoProgress} className="mb-4" />
                  
                  {isVideoCompleted && currentChapterData.checkpoint && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 text-green-800 mb-2">
                        <Trophy className="h-5 w-5" />
                        <span className="font-medium">Chapter Complete!</span>
                      </div>
                      <p className="text-sm text-green-600 mb-3">
                        Great job! Now it's time for your checkpoint to test your understanding.
                      </p>
                      <Button
                        onClick={() => setShowCheckpoint(true)}
                        className="gap-2"
                        size="sm"
                      >
                        <Target className="h-4 w-4" />
                        Start {currentChapterData.checkpoint.title}
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Chapter Content */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Chapter Notes
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="prose prose-sm max-w-none">
                  <div dangerouslySetInnerHTML={{ __html: currentChapterData.content.replace(/\n/g, '<br/>') }} />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Progress Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Course Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-primary">
                      {Math.round(((currentChapter + (isVideoCompleted ? 1 : 0)) / course.chapters.length) * 100)}%
                    </div>
                    <p className="text-sm text-muted-foreground">Complete</p>
                  </div>
                  
                  <Progress value={((currentChapter + (isVideoCompleted ? 1 : 0)) / course.chapters.length) * 100} />
                  
                  <div className="text-center text-sm text-muted-foreground">
                    Chapter {currentChapter + 1} of {course.chapters.length}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Chapter List */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Chapters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {course.chapters.map((chapter, index) => (
                    <div
                      key={chapter.id}
                      className={`p-3 rounded-lg border cursor-pointer transition-all ${
                        index === currentChapter
                          ? 'bg-primary/10 border-primary'
                          : chapter.completed
                          ? 'bg-green-50 border-green-200'
                          : 'bg-background border-border hover:bg-accent'
                      }`}
                      onClick={() => setCurrentChapter(index)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {chapter.completed ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : index === currentChapter ? (
                            <Play className="h-4 w-4 text-primary" />
                          ) : (
                            <div className="w-4 h-4 border rounded-full border-muted-foreground" />
                          )}
                          <span className="text-sm font-medium">Ch. {index + 1}</span>
                        </div>
                        {chapter.checkpoint && (
                          <Badge variant={chapter.checkpoint.passed ? "default" : "outline"} size="sm">
                            {chapter.checkpoint.passed ? "✓" : "Quiz"}
                          </Badge>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground mt-1 line-clamp-2">
                        {chapter.title}
                      </p>
                      <div className="flex items-center gap-1 mt-1 text-xs text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {chapter.duration} min
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Attention Status */}
            {currentAttention < 70 && (
              <Card className="border-orange-200 bg-orange-50">
                <CardHeader>
                  <CardTitle className="text-lg text-orange-800 flex items-center gap-2">
                    <AlertTriangle className="h-5 w-5" />
                    Attention Alert
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-orange-700 mb-3">
                    Your attention level is {currentAttention}%. Consider taking a quick break or trying a focus exercise.
                  </p>
                  <Button
                    onClick={() => setShowConcentrationVideos(true)}
                    size="sm"
                    variant="outline"
                    className="w-full"
                  >
                    <Lightbulb className="h-4 w-4 mr-2" />
                    Focus Exercise
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>

      {/* Concentration Videos Modal */}
      {showConcentrationVideos && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b bg-gradient-to-r from-orange-50 to-yellow-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-orange-800">Attention Boost</h3>
                  <p className="text-sm text-orange-600">
                    Take a moment to restore your focus with these exercises
                  </p>
                </div>
                <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                  Focus: {currentAttention}%
                </Badge>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {concentrationVideos.map((video, index) => (
                <div
                  key={video.id}
                  className="flex gap-4 p-4 border rounded-xl hover:bg-accent/50 transition-all cursor-pointer"
                  onClick={() => {
                    window.open(`https://youtube.com/watch?v=${video.id}`, '_blank');
                  }}
                >
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-24 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm mb-1">{video.title}</h4>
                    <p className="text-xs text-muted-foreground mb-2">{video.description}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {video.duration}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 border-t">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  Complete an exercise and return when ready
                </p>
                <Button
                  onClick={() => setShowConcentrationVideos(false)}
                  variant="outline"
                >
                  Continue Learning
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Checkpoint Quiz Modal */}
      {showCheckpoint && currentChapterData.checkpoint && !showCheckpointResults && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b bg-gradient-to-r from-blue-50 to-purple-50">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-blue-800">{currentChapterData.checkpoint.title}</h3>
                  <p className="text-sm text-blue-600">
                    Test your understanding of this chapter
                  </p>
                </div>
                <Badge variant="secondary">
                  Question {currentQuestion + 1} of {currentChapterData.checkpoint.questions?.length}
                </Badge>
              </div>
            </div>

            <div className="p-6">
              {currentChapterData.checkpoint.questions && (
                <div className="space-y-6">
                  <div>
                    <Progress value={((currentQuestion + 1) / currentChapterData.checkpoint.questions.length) * 100} className="mb-4" />
                  </div>

                  <div>
                    <h4 className="text-lg font-semibold mb-4">
                      {currentChapterData.checkpoint.questions[currentQuestion].question}
                    </h4>

                    {currentChapterData.checkpoint.questions[currentQuestion].type === "multiple-choice" && (
                      <RadioGroup
                        value={answers[currentChapterData.checkpoint.questions[currentQuestion].id]?.toString()}
                        onValueChange={(value) => handleAnswerSubmit(
                          currentChapterData.checkpoint.questions[currentQuestion].id,
                          parseInt(value)
                        )}
                      >
                        {currentChapterData.checkpoint.questions[currentQuestion].options?.map((option, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                            <Label htmlFor={`option-${index}`} className="cursor-pointer">
                              {option}
                            </Label>
                          </div>
                        ))}
                      </RadioGroup>
                    )}

                    {currentChapterData.checkpoint.questions[currentQuestion].type === "text" && (
                      <Textarea
                        placeholder="Enter your answer here..."
                        value={answers[currentChapterData.checkpoint.questions[currentQuestion].id] || ""}
                        onChange={(e) => handleAnswerSubmit(
                          currentChapterData.checkpoint.questions[currentQuestion].id,
                          e.target.value
                        )}
                      />
                    )}
                  </div>

                  <div className="flex items-center justify-between">
                    <Button
                      variant="outline"
                      onClick={() => setCurrentQuestion(Math.max(0, currentQuestion - 1))}
                      disabled={currentQuestion === 0}
                    >
                      Previous
                    </Button>

                    {currentQuestion < currentChapterData.checkpoint.questions.length - 1 ? (
                      <Button
                        onClick={() => setCurrentQuestion(currentQuestion + 1)}
                        disabled={!answers[currentChapterData.checkpoint.questions[currentQuestion].id]}
                      >
                        Next Question
                      </Button>
                    ) : (
                      <Button
                        onClick={submitCheckpoint}
                        disabled={!answers[currentChapterData.checkpoint.questions[currentQuestion].id]}
                        className="gap-2"
                      >
                        <CheckCircle className="h-4 w-4" />
                        Submit Quiz
                      </Button>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Checkpoint Results Modal */}
      {showCheckpointResults && currentChapterData.checkpoint && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className={`p-6 border-b ${checkpointScore >= currentChapterData.checkpoint.requiredScore ? 'bg-gradient-to-r from-green-50 to-emerald-50' : 'bg-gradient-to-r from-red-50 to-orange-50'}`}>
              <div className="text-center">
                <div className={`w-16 h-16 rounded-full mx-auto mb-4 flex items-center justify-center ${checkpointScore >= currentChapterData.checkpoint.requiredScore ? 'bg-green-100' : 'bg-red-100'}`}>
                  {checkpointScore >= currentChapterData.checkpoint.requiredScore ? (
                    <Award className="h-8 w-8 text-green-600" />
                  ) : (
                    <AlertTriangle className="h-8 w-8 text-red-600" />
                  )}
                </div>
                <h3 className={`text-2xl font-bold mb-2 ${checkpointScore >= currentChapterData.checkpoint.requiredScore ? 'text-green-800' : 'text-red-800'}`}>
                  {checkpointScore >= currentChapterData.checkpoint.requiredScore ? 'Congratulations!' : 'Keep Learning!'}
                </h3>
                <p className={`text-lg ${checkpointScore >= currentChapterData.checkpoint.requiredScore ? 'text-green-600' : 'text-red-600'}`}>
                  You scored {checkpointScore}%
                </p>
                <p className={`text-sm ${checkpointScore >= currentChapterData.checkpoint.requiredScore ? 'text-green-600' : 'text-red-600'}`}>
                  {checkpointScore >= currentChapterData.checkpoint.requiredScore 
                    ? `You passed! (Required: ${currentChapterData.checkpoint.requiredScore}%)`
                    : `You need ${currentChapterData.checkpoint.requiredScore}% to pass`
                  }
                </p>
              </div>
            </div>

            <div className="p-6">
              <div className="text-center space-y-4">
                {checkpointScore >= currentChapterData.checkpoint.requiredScore ? (
                  <>
                    <p className="text-muted-foreground">
                      Great job! You've mastered this chapter's concepts.
                    </p>
                    <div className="flex gap-3 justify-center">
                      <Button
                        onClick={() => {
                          setShowCheckpoint(false);
                          setShowCheckpointResults(false);
                        }}
                        variant="outline"
                      >
                        Review Chapter
                      </Button>
                      <Button
                        onClick={handleNextChapter}
                        className="gap-2"
                        disabled={currentChapter === course.chapters.length - 1}
                      >
                        Next Chapter
                        <ChevronRight className="h-4 w-4" />
                      </Button>
                    </div>
                  </>
                ) : (
                  <>
                    <p className="text-muted-foreground">
                      Don't worry! Review the chapter content and try again.
                    </p>
                    <div className="flex gap-3 justify-center">
                      <Button
                        onClick={() => {
                          setShowCheckpoint(false);
                          setShowCheckpointResults(false);
                          setCurrentQuestion(0);
                          setAnswers({});
                        }}
                        variant="outline"
                      >
                        Review Chapter
                      </Button>
                      <Button
                        onClick={() => {
                          setShowCheckpointResults(false);
                          setCurrentQuestion(0);
                          setAnswers({});
                        }}
                      >
                        Retry Quiz
                      </Button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
