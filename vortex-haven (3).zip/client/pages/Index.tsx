import { useEffect, useRef, useState } from "react";
import * as faceapi from "face-api.js";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, Camera, Eye, Heart, Activity, TrendingUp, BookOpen, Target } from "lucide-react";

interface EmotionData {
  expression: string;
  confidence: number;
  timestamp: number;
}

interface AttentionData {
  focused: boolean;
  gazeDirection: string;
  blinkRate: number;
  timestamp: number;
}

interface LearningSession {
  topic: string;
  duration: number;
  engagementScore: number;
  emotionalState: string;
  completionRate: number;
}

export default function Index() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [emotions, setEmotions] = useState<EmotionData[]>([]);
  const [attention, setAttention] = useState<AttentionData | null>(null);
  const [currentEmotion, setCurrentEmotion] = useState<string>("neutral");
  const [engagementScore, setEngagementScore] = useState(75);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [cameraStatus, setCameraStatus] = useState<"idle" | "requesting" | "granted" | "denied">("idle");

  // Mock learning sessions data
  const [learningSessions] = useState<LearningSession[]>([
    { topic: "Machine Learning Basics", duration: 45, engagementScore: 87, emotionalState: "focused", completionRate: 92 },
    { topic: "Neural Networks", duration: 60, engagementScore: 94, emotionalState: "happy", completionRate: 88 },
    { topic: "Data Structures", duration: 30, engagementScore: 76, emotionalState: "neutral", completionRate: 95 },
  ]);

  // Load face-api.js models
  useEffect(() => {
    const loadModels = async () => {
      try {
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
          faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
          faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
          faceapi.nets.faceExpressionNet.loadFromUri('/models'),
        ]);
        setIsModelLoaded(true);
      } catch (error) {
        console.log("Models not found, continuing with mock data");
        setIsModelLoaded(true);
      }
    };
    loadModels();
  }, []);

  // Start webcam with improved permission handling
  const startCamera = async () => {
    setCameraStatus("requesting");

    try {
      // Check if getUserMedia is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error("Camera not supported");
      }

      console.log("Requesting camera access...");

      // Request camera permission with detailed constraints
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user"
        }
      });

      console.log("Camera access granted, setting up video...");

      if (videoRef.current) {
        videoRef.current.srcObject = stream;

        // Set up the video element properly
        videoRef.current.onloadedmetadata = () => {
          console.log("Video metadata loaded, playing video...");
          videoRef.current?.play().then(() => {
            console.log("Video playing successfully");
            setCameraStatus("granted");
            setIsCameraActive(true);
            setIsAnalyzing(true);
            startFaceDetection();
          }).catch((playError) => {
            console.error("Error playing video:", playError);
            setCameraStatus("denied");
            startMockAnalysis();
          });
        };

        videoRef.current.onerror = (videoError) => {
          console.error("Video error:", videoError);
          setCameraStatus("denied");
          startMockAnalysis();
        };
      }
    } catch (error) {
      console.error("Error accessing camera:", error);
      setCameraStatus("denied");

      // Handle different types of camera errors
      let errorMessage = "Camera access failed. ";
      if (error.name === "NotAllowedError") {
        errorMessage += "Please allow camera access when prompted by your browser.";
      } else if (error.name === "NotFoundError") {
        errorMessage += "No camera found on this device.";
      } else if (error.name === "NotReadableError") {
        errorMessage += "Camera is already in use by another application.";
      } else if (error.message === "Camera not supported") {
        errorMessage += "Camera access is not supported in this browser.";
      } else {
        errorMessage += "Unable to access camera.";
      }

      alert(errorMessage + " Starting with demo mode to show functionality.");

      // Start with mock data if camera access is denied
      startMockAnalysis();
    }
  };

  // Start mock analysis for demo purposes
  const startMockAnalysis = () => {
    console.log("Starting mock analysis...");
    setIsCameraActive(false); // Keep camera inactive for mock mode
    setIsAnalyzing(true);

    const emotions = ["happy", "focused", "neutral", "surprised"];
    const mockInterval = setInterval(() => {
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      const confidence = Math.random() * 0.4 + 0.6; // 60-100% confidence

      setCurrentEmotion(randomEmotion);
      setEmotions(prev => [...prev.slice(-10), {
        expression: randomEmotion,
        confidence,
        timestamp: Date.now()
      }]);

      setAttention({
        focused: Math.random() > 0.3,
        gazeDirection: Math.random() > 0.5 ? "center" : "away",
        blinkRate: Math.random() * 20 + 10,
        timestamp: Date.now()
      });

      setEngagementScore(Math.floor(Math.random() * 30 + 70));
    }, 2000);

    // Clean up interval after 30 seconds for demo
    setTimeout(() => clearInterval(mockInterval), 30000);
  };

  // Face detection loop
  const startFaceDetection = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const detectFaces = async () => {
      if (!videoRef.current || !canvasRef.current || !isAnalyzing) return;

      try {
        const detections = await faceapi
          .detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions())
          .withFaceLandmarks()
          .withFaceExpressions();

        if (detections.length > 0) {
          const expressions = detections[0].expressions;
          const dominantExpression = Object.keys(expressions).reduce((a, b) =>
            expressions[a as keyof typeof expressions] > expressions[b as keyof typeof expressions] ? a : b
          );

          setCurrentEmotion(dominantExpression);
          setEmotions(prev => [...prev.slice(-10), {
            expression: dominantExpression,
            confidence: expressions[dominantExpression as keyof typeof expressions],
            timestamp: Date.now()
          }]);

          // Calculate engagement based on expressions
          const positiveEmotions = expressions.happy + expressions.surprised;
          const focusScore = Math.min(100, (positiveEmotions * 100 + expressions.neutral * 50));
          setEngagementScore(Math.floor(focusScore));
        }
      } catch (error) {
        console.error("Face detection error:", error);
      }

      setTimeout(detectFaces, 1000);
    };

    detectFaces();
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsCameraActive(false);
    setIsAnalyzing(false);
    setCameraStatus("idle");
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case "happy": return "text-emotion-happy bg-emotion-happy/10";
      case "sad": return "text-emotion-sad bg-emotion-sad/10";
      case "angry": return "text-emotion-angry bg-emotion-angry/10";
      case "surprised": return "text-emotion-surprised bg-emotion-surprised/10";
      case "focused": return "text-emotion-focused bg-emotion-focused/10";
      default: return "text-emotion-neutral bg-emotion-neutral/10";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <Brain className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                  NeuroLearn AI
                </h1>
                <p className="text-sm text-muted-foreground">Adaptive Learning Ecosystem</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="gap-2">
                <Activity className="h-4 w-4" />
                {isAnalyzing ? "Analyzing" : "Ready"}
              </Badge>
              {cameraStatus !== "idle" && (
                <Badge
                  variant={cameraStatus === "granted" ? "default" : cameraStatus === "requesting" ? "secondary" : "destructive"}
                  className="gap-2"
                >
                  <Camera className="h-4 w-4" />
                  {cameraStatus === "granted" ? "Camera Active" :
                   cameraStatus === "requesting" ? "Requesting Access" : "Camera Denied"}
                </Badge>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Main Dashboard */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Camera & Detection Section */}
          <div className="lg:col-span-2 space-y-6">
            <Card className="overflow-hidden">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <Camera className="h-5 w-5" />
                      Real-time Analysis
                    </CardTitle>
                    <CardDescription>
                      Facial expression and attention tracking for adaptive learning
                    </CardDescription>
                  </div>
                  {!isCameraActive ? (
                    <Button
                      onClick={startCamera}
                      className="gap-2"
                      disabled={cameraStatus === "requesting"}
                    >
                      <Camera className="h-4 w-4" />
                      {cameraStatus === "requesting" ? "Requesting Permission..." : "Allow Camera Access"}
                    </Button>
                  ) : (
                    <Button onClick={stopCamera} variant="destructive" className="gap-2">
                      Stop Analysis
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                <div className="relative bg-neutral-900 rounded-xl overflow-hidden aspect-video">
                  {isCameraActive ? (
                    <>
                      <video
                        ref={videoRef}
                        autoPlay
                        muted
                        playsInline
                        className="w-full h-full object-cover"
                        style={{ transform: "scaleX(-1)" }}
                      />
                      <canvas
                        ref={canvasRef}
                        className="absolute top-0 left-0 w-full h-full"
                        style={{ transform: "scaleX(-1)" }}
                      />
                      <div className="absolute top-4 left-4 space-y-2">
                        <Badge className={`gap-2 ${getEmotionColor(currentEmotion)}`}>
                          <Heart className="h-4 w-4" />
                          {currentEmotion}
                        </Badge>
                        {attention && (
                          <Badge variant={attention.focused ? "default" : "secondary"} className="gap-2">
                            <Eye className="h-4 w-4" />
                            {attention.focused ? "Focused" : "Distracted"}
                          </Badge>
                        )}
                      </div>
                    </>
                  ) : (
                    <div className="flex items-center justify-center h-full text-white/50">
                      <div className="text-center">
                        <Camera className="h-16 w-16 mx-auto mb-4" />
                        <p className="text-lg font-medium">
                          {cameraStatus === "requesting" ? "Requesting Camera Access..." :
                           cameraStatus === "denied" ? "Camera Access Denied" : "Camera Not Active"}
                        </p>
                        <p className="text-sm">
                          {cameraStatus === "requesting" ? "Please allow camera access in your browser" :
                           cameraStatus === "denied" ? "Demo mode active - showing sample data" :
                           "Click 'Allow Camera Access' to begin analysis"}
                        </p>
                        {cameraStatus === "denied" && isAnalyzing && (
                          <div className="mt-4">
                            <Badge className={`gap-2 ${getEmotionColor(currentEmotion)}`}>
                              <Heart className="h-4 w-4" />
                              Demo: {currentEmotion}
                            </Badge>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Adaptive Content Section */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Adaptive Content Delivery
                </CardTitle>
                <CardDescription>
                  Content automatically adjusts based on your emotional state and attention
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg bg-gradient-to-r from-primary/5 to-neural-100/50">
                    <h3 className="font-semibold mb-2">Current Recommendation</h3>
                    <p className="text-sm text-muted-foreground mb-3">
                      Based on your {currentEmotion} emotional state, we recommend:
                    </p>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <Target className="h-4 w-4 text-primary" />
                        <span className="font-medium">Interactive coding exercises</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Target className="h-4 w-4 text-primary" />
                        <span className="font-medium">Visual learning materials</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Target className="h-4 w-4 text-primary" />
                        <span className="font-medium">Short 15-minute sessions</span>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Analytics Sidebar */}
          <div className="space-y-6">
            {/* Engagement Score */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Engagement Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary">{engagementScore}%</div>
                    <p className="text-sm text-muted-foreground">Current Session</p>
                  </div>
                  <Progress value={engagementScore} className="h-3" />
                  <div className="flex justify-between text-xs text-muted-foreground">
                    <span>Low</span>
                    <span>Optimal</span>
                    <span>High</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Emotion Timeline */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Emotion Timeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {emotions.slice(-8).reverse().map((emotion, index) => (
                    <div key={index} className="flex items-center justify-between text-sm">
                      <Badge size="sm" className={getEmotionColor(emotion.expression)}>
                        {emotion.expression}
                      </Badge>
                      <span className="text-muted-foreground">
                        {Math.floor(emotion.confidence * 100)}%
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Learning Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Learning Progress
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {learningSessions.map((session, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-sm">{session.topic}</span>
                        <Badge size="sm" className={getEmotionColor(session.emotionalState)}>
                          {session.emotionalState}
                        </Badge>
                      </div>
                      <Progress value={session.completionRate} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{session.duration}min</span>
                        <span>{session.engagementScore}% engaged</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Features Overview */}
        <div className="grid md:grid-cols-3 gap-6">
          <Card className="border-2 border-primary/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Heart className="h-5 w-5 text-emotion-happy" />
                Emotion Recognition
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Advanced facial expression analysis to understand your emotional state and adapt content accordingly.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-neural-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Eye className="h-5 w-5 text-emotion-focused" />
                Attention Tracking
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Real-time eye movement analysis to measure focus and engagement during learning sessions.
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-accent/20">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <Brain className="h-5 w-5 text-primary" />
                Adaptive Learning
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Personalized content delivery based on your learning style, emotions, and attention patterns.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
