import { useState } from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Brain, Users, BookOpen, BarChart3, Plus, Edit, Trash2, Upload, Download, TrendingUp, Eye, Heart, Activity } from "lucide-react";

interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  students: number;
  completion: number;
  status: "published" | "draft" | "archived";
  created: string;
}

interface User {
  id: string;
  name: string;
  email: string;
  joinDate: string;
  coursesCompleted: number;
  avgEngagement: number;
  lastActive: string;
  emotionalState: string;
}

interface AnalyticsData {
  totalUsers: number;
  activeUsers: number;
  totalCourses: number;
  avgEngagement: number;
  completionRate: number;
  emotionDistribution: {
    happy: number;
    focused: number;
    neutral: number;
    frustrated: number;
  };
}

export default function Admin() {
  const [activeTab, setActiveTab] = useState("overview");
  
  // Mock analytics data
  const [analytics] = useState<AnalyticsData>({
    totalUsers: 15742,
    activeUsers: 3421,
    totalCourses: 156,
    avgEngagement: 87,
    completionRate: 73,
    emotionDistribution: {
      happy: 35,
      focused: 40,
      neutral: 20,
      frustrated: 5
    }
  });

  // Mock courses data
  const [courses] = useState<Course[]>([
    {
      id: "1",
      title: "Advanced React Patterns",
      description: "Learn advanced React patterns and optimization techniques",
      instructor: "Sarah Chen",
      students: 1234,
      completion: 78,
      status: "published",
      created: "2024-01-15"
    },
    {
      id: "2",
      title: "Machine Learning Fundamentals",
      description: "Introduction to ML concepts and practical applications",
      instructor: "Dr. Michael Roberts",
      students: 856,
      completion: 65,
      status: "published",
      created: "2024-02-03"
    },
    {
      id: "3",
      title: "System Design Masterclass",
      description: "Master system design concepts for technical interviews",
      instructor: "Alex Kumar",
      students: 432,
      completion: 0,
      status: "draft",
      created: "2024-03-10"
    }
  ]);

  // Mock users data
  const [users] = useState<User[]>([
    {
      id: "1",
      name: "Alice Johnson",
      email: "alice@example.com",
      joinDate: "2024-01-10",
      coursesCompleted: 8,
      avgEngagement: 94,
      lastActive: "2024-03-15",
      emotionalState: "focused"
    },
    {
      id: "2",
      name: "Bob Smith",
      email: "bob@example.com",
      joinDate: "2024-02-05",
      coursesCompleted: 5,
      avgEngagement: 76,
      lastActive: "2024-03-14",
      emotionalState: "happy"
    },
    {
      id: "3",
      name: "Carol Williams",
      email: "carol@example.com",
      joinDate: "2024-01-20",
      coursesCompleted: 12,
      avgEngagement: 89,
      lastActive: "2024-03-13",
      emotionalState: "neutral"
    }
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "published": return "bg-green-100 text-green-800";
      case "draft": return "bg-yellow-100 text-yellow-800";
      case "archived": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case "happy": return "text-emotion-happy bg-emotion-happy/10";
      case "focused": return "text-emotion-focused bg-emotion-focused/10";
      case "neutral": return "text-emotion-neutral bg-emotion-neutral/10";
      case "frustrated": return "text-emotion-angry bg-emotion-angry/10";
      default: return "text-emotion-neutral bg-emotion-neutral/10";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-primary/10 rounded-xl">
                <Brain className="h-8 w-8 text-primary" />
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                  NeuroLearn Admin
                </h1>
                <p className="text-sm text-muted-foreground">Platform Management Dashboard</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <Link to="/dashboard">
                <Button variant="ghost">Back to App</Button>
              </Link>
              <Badge variant="outline" className="gap-2">
                <Activity className="h-4 w-4" />
                Admin Access
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="courses">Course Management</TabsTrigger>
            <TabsTrigger value="users">User Management</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-8">
            {/* Stats Overview */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-primary">{analytics.totalUsers.toLocaleString()}</div>
                    <Users className="h-5 w-5 text-primary" />
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">+12% from last month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Active Users</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-emotion-happy">{analytics.activeUsers.toLocaleString()}</div>
                    <Activity className="h-5 w-5 text-emotion-happy" />
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">+8% from last week</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Courses</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-emotion-focused">{analytics.totalCourses}</div>
                    <BookOpen className="h-5 w-5 text-emotion-focused" />
                  </div>
                  <p className="text-sm text-muted-foreground mt-1">+3 new this month</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Avg Engagement</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="text-2xl font-bold text-accent">{analytics.avgEngagement}%</div>
                    <TrendingUp className="h-5 w-5 text-accent" />
                  </div>
                  <Progress value={analytics.avgEngagement} className="mt-2" />
                </CardContent>
              </Card>
            </div>

            {/* Emotion Distribution */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5" />
                  Real-time Emotion Distribution
                </CardTitle>
                <CardDescription>
                  Current emotional states of active learners
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-4 gap-4">
                  <div className="text-center space-y-2">
                    <div className="text-2xl font-bold text-emotion-happy">{analytics.emotionDistribution.happy}%</div>
                    <Badge className="w-full justify-center bg-emotion-happy/10 text-emotion-happy">Happy</Badge>
                    <Progress value={analytics.emotionDistribution.happy} className="h-2" />
                  </div>
                  <div className="text-center space-y-2">
                    <div className="text-2xl font-bold text-emotion-focused">{analytics.emotionDistribution.focused}%</div>
                    <Badge className="w-full justify-center bg-emotion-focused/10 text-emotion-focused">Focused</Badge>
                    <Progress value={analytics.emotionDistribution.focused} className="h-2" />
                  </div>
                  <div className="text-center space-y-2">
                    <div className="text-2xl font-bold text-emotion-neutral">{analytics.emotionDistribution.neutral}%</div>
                    <Badge className="w-full justify-center bg-emotion-neutral/10 text-emotion-neutral">Neutral</Badge>
                    <Progress value={analytics.emotionDistribution.neutral} className="h-2" />
                  </div>
                  <div className="text-center space-y-2">
                    <div className="text-2xl font-bold text-emotion-angry">{analytics.emotionDistribution.frustrated}%</div>
                    <Badge className="w-full justify-center bg-emotion-angry/10 text-emotion-angry">Frustrated</Badge>
                    <Progress value={analytics.emotionDistribution.frustrated} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Course Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {courses.slice(0, 3).map((course) => (
                      <div key={course.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <h4 className="font-medium">{course.title}</h4>
                          <p className="text-sm text-muted-foreground">{course.students} students</p>
                        </div>
                        <Badge className={getStatusColor(course.status)}>
                          {course.status}
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Top Performing Students</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {users.slice(0, 3).map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div>
                          <h4 className="font-medium">{user.name}</h4>
                          <p className="text-sm text-muted-foreground">{user.coursesCompleted} courses completed</p>
                        </div>
                        <div className="text-right">
                          <div className="font-semibold">{user.avgEngagement}%</div>
                          <Badge size="sm" className={getEmotionColor(user.emotionalState)}>
                            {user.emotionalState}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Course Management Tab */}
          <TabsContent value="courses" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Course Management</h2>
              <Button className="gap-2">
                <Plus className="h-4 w-4" />
                Create Course
              </Button>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>All Courses</CardTitle>
                <CardDescription>
                  Manage your learning content and track student progress
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Course Title</TableHead>
                      <TableHead>Instructor</TableHead>
                      <TableHead>Students</TableHead>
                      <TableHead>Completion</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {courses.map((course) => (
                      <TableRow key={course.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{course.title}</div>
                            <div className="text-sm text-muted-foreground">{course.description}</div>
                          </div>
                        </TableCell>
                        <TableCell>{course.instructor}</TableCell>
                        <TableCell>{course.students.toLocaleString()}</TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="text-sm">{course.completion}%</div>
                            <Progress value={course.completion} className="h-1" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getStatusColor(course.status)}>
                            {course.status}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <BarChart3 className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* User Management Tab */}
          <TabsContent value="users" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">User Management</h2>
              <div className="flex gap-2">
                <Button variant="outline" className="gap-2">
                  <Download className="h-4 w-4" />
                  Export Data
                </Button>
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add User
                </Button>
              </div>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>All Users</CardTitle>
                <CardDescription>
                  Monitor user engagement and learning progress
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>User</TableHead>
                      <TableHead>Join Date</TableHead>
                      <TableHead>Courses</TableHead>
                      <TableHead>Engagement</TableHead>
                      <TableHead>Current State</TableHead>
                      <TableHead>Last Active</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div>
                            <div className="font-medium">{user.name}</div>
                            <div className="text-sm text-muted-foreground">{user.email}</div>
                          </div>
                        </TableCell>
                        <TableCell>{new Date(user.joinDate).toLocaleDateString()}</TableCell>
                        <TableCell>{user.coursesCompleted}</TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            <div className="text-sm">{user.avgEngagement}%</div>
                            <Progress value={user.avgEngagement} className="h-1" />
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge className={getEmotionColor(user.emotionalState)}>
                            {user.emotionalState}
                          </Badge>
                        </TableCell>
                        <TableCell>{new Date(user.lastActive).toLocaleDateString()}</TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Edit className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Platform Analytics</h2>
              <Button variant="outline" className="gap-2">
                <Download className="h-4 w-4" />
                Export Report
              </Button>
            </div>

            <div className="grid lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Learning Engagement Trends</CardTitle>
                  <CardDescription>
                    Track how student engagement changes over time
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-muted rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">Engagement Chart Placeholder</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Emotion Analysis</CardTitle>
                  <CardDescription>
                    Real-time emotion distribution across all learners
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-muted rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">Emotion Pie Chart Placeholder</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Course Completion Rates</CardTitle>
                  <CardDescription>
                    Track completion rates across different courses
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-muted rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">Completion Bar Chart Placeholder</p>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Attention Patterns</CardTitle>
                  <CardDescription>
                    Analyze when students are most focused during lessons
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-muted rounded-lg flex items-center justify-center">
                    <p className="text-muted-foreground">Attention Heatmap Placeholder</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
