export default function TestDashboard() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100 flex items-center justify-center">
      <div className="text-center">
        <h1 className="text-4xl font-bold text-primary mb-4">Dashboard Test Page</h1>
        <p className="text-muted-foreground">This is the Dashboard component</p>
        <p className="text-sm text-muted-foreground mt-2">Route: /dashboard</p>
      </div>
    </div>
  );
}
