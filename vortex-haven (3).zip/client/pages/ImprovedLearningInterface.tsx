import { useState, useEffect, useRef } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { AudioUtils } from "@/utils/audioUtils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Brain, Eye, Play, Pause, SkipForward, SkipBack, BookOpen, 
  CheckCircle, Clock, Trophy, AlertTriangle, Target, Lightbulb,
  Camera, Settings, ArrowLeft, Award, Search, Youtube, Volume2,
  VolumeX, X, Zap, Bell, CameraOff
} from "lucide-react";

// YouTube API simulation - In real app, this would use YouTube API
const YOUTUBE_SEARCH_RESULTS = {
  "mathematics": [
    {
      id: "3s7h2MHQtxc",
      title: "Algebra Basics: What Is Algebra? - Math Antics",
      thumbnail: "https://img.youtube.com/vi/3s7h2MHQtxc/maxresdefault.jpg",
      duration: "12:14",
      description: "Learn the basics of algebra with clear explanations"
    },
    {
      id: "fng6c2NLz1c",
      title: "Calculus in 10 Minutes",
      thumbnail: "https://img.youtube.com/vi/fng6c2NLz1c/maxresdefault.jpg",
      duration: "10:23",
      description: "Quick introduction to calculus concepts"
    }
  ],
  "science": [
    {
      id: "wWnfJ0-xXRE",
      title: "Introduction to Physics - What is Physics?",
      thumbnail: "https://img.youtube.com/vi/wWnfJ0-xXRE/maxresdefault.jpg",
      duration: "15:45",
      description: "Basic physics concepts explained simply"
    },
    {
      id: "qNKe3yrm9vE",
      title: "Chemistry Basics - Atoms and Elements",
      thumbnail: "https://img.youtube.com/vi/qNKe3yrm9vE/maxresdefault.jpg",
      duration: "18:32",
      description: "Understanding atoms and the periodic table"
    }
  ],
  "english": [
    {
      id: "qzkx7RjdUhU",
      title: "English Grammar: Sentence Structure",
      thumbnail: "https://img.youtube.com/vi/qzkx7RjdUhU/maxresdefault.jpg",
      duration: "14:28",
      description: "Learn about proper sentence construction"
    },
    {
      id: "YQHsXMglC9A",
      title: "Improve Your Vocabulary - Word Formation",
      thumbnail: "https://img.youtube.com/vi/YQHsXMglC9A/maxresdefault.jpg",
      duration: "20:15",
      description: "Techniques for building better vocabulary"
    }
  ],
  "reading": [
    {
      id: "p6LkoBR3vNE",
      title: "Reading Comprehension Strategies",
      thumbnail: "https://img.youtube.com/vi/p6LkoBR3vNE/maxresdefault.jpg",
      duration: "16:42",
      description: "Improve your reading comprehension skills"
    }
  ],
  "programming": [
    {
      id: "zOjov-2OZ0E",
      title: "Programming for Beginners - Full Course",
      thumbnail: "https://img.youtube.com/vi/zOjov-2OZ0E/maxresdefault.jpg",
      duration: "41:53",
      description: "Complete introduction to programming concepts"
    }
  ]
};

interface VideoRequest {
  id: string;
  title: string;
  subject: string;
  description: string;
  requestedBy: string;
  approved: boolean;
  youtubeId?: string;
  thumbnail?: string;
  duration?: string;
}

interface UserProgress {
  courseId: string;
  chaptersCompleted: number;
  totalWatchTime: number;
  lastWatched: string;
  attentionScore: number;
  targetsMet: number;
}

interface FocusSession {
  startTime: number;
  endTime?: number;
  averageAttention: number;
  distractions: number;
  targetReached: boolean;
}

export default function ImprovedLearningInterface() {
  const { courseId } = useParams();
  const navigate = useNavigate();
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Video and content state
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [videoProgress, setVideoProgress] = useState(0);
  const [watchTime, setWatchTime] = useState(0);
  const [currentVideoId, setCurrentVideoId] = useState("");

  // Real camera and focus detection
  const [currentAttention, setCurrentAttention] = useState(0);
  const [isLookingAtScreen, setIsLookingAtScreen] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [focusSession, setFocusSession] = useState<FocusSession | null>(null);
  const [showFocusExercise, setShowFocusExercise] = useState(false);
  const [showConcentrationVideo, setShowConcentrationVideo] = useState(false);
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [consecutiveLowFocus, setConsecutiveLowFocus] = useState(0);
  const [lastSoundTime, setLastSoundTime] = useState(0);

  // Face detection variables
  const [faceDetected, setFaceDetected] = useState(false);
  const [eyesOpen, setEyesOpen] = useState(false);
  const [lookingAtCenter, setLookingAtCenter] = useState(false);

  // Target and achievement system
  const [currentTarget, setCurrentTarget] = useState({
    type: "watch_time",
    goal: 30, // 30 minutes
    current: 0,
    completed: false
  });
  const [showTargetPopup, setShowTargetPopup] = useState(false);

  // Video requests and YouTube integration
  const [videoRequests, setVideoRequests] = useState<VideoRequest[]>([]);
  const [showVideoRequest, setShowVideoRequest] = useState(false);
  const [userInterestVideos, setUserInterestVideos] = useState<any[]>([]);
  const [newVideoRequest, setNewVideoRequest] = useState({
    title: "",
    subject: "",
    description: ""
  });

  // User progress tracking
  const [userProgress, setUserProgress] = useState<UserProgress>({
    courseId: courseId || "",
    chaptersCompleted: 0,
    totalWatchTime: 0,
    lastWatched: new Date().toISOString(),
    attentionScore: 0,
    targetsMet: 0
  });

  // Available concentration videos (YouTube integrated)
  const concentrationVideos = [
    {
      id: "6R4VdbOOhds",
      title: "5 Minute Meditation for Focus",
      thumbnail: "https://img.youtube.com/vi/6R4VdbOOhds/maxresdefault.jpg",
      duration: "5:00",
      description: "Quick meditation to restore concentration"
    },
    {
      id: "1ZYbU82GVz4",
      title: "Deep Focus Music - 1 Hour",
      thumbnail: "https://img.youtube.com/vi/1ZYbU82GVz4/maxresdefault.jpg",
      duration: "60:00",
      description: "Ambient music for deep concentration"
    },
    {
      id: "yF1l8e92BRQ",
      title: "Breathing Exercise for Attention",
      thumbnail: "https://img.youtube.com/vi/yF1l8e92BRQ/maxresdefault.jpg",
      duration: "3:30",
      description: "Simple breathing technique to improve focus"
    }
  ];

  // Initialize camera and load user data
  useEffect(() => {
    loadUserData();
    loadUserInterestVideos();
    initializeCamera();

    // Start focus session
    setFocusSession({
      startTime: Date.now(),
      averageAttention: 0,
      distractions: 0,
      targetReached: false
    });

    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach(track => track.stop());
      }
    };
  }, [courseId]);

  const loadUserData = () => {
    // Load user profile to get interests
    const userProfile = localStorage.getItem("neurolearn_user_profile");
    
    // Load progress
    const savedProgress = localStorage.getItem(`progress_${courseId}`);
    if (savedProgress) {
      setUserProgress(JSON.parse(savedProgress));
    }

    // Load video requests
    const savedRequests = localStorage.getItem("video_requests");
    if (savedRequests) {
      setVideoRequests(JSON.parse(savedRequests));
    }
  };

  const loadUserInterestVideos = () => {
    // Get user profile to extract interests
    const userProfile = localStorage.getItem("neurolearn_user_profile");
    if (userProfile) {
      const profile = JSON.parse(userProfile);
      const subjects = profile.academicInfo?.subjects || [];
      const goals = profile.personalInfo?.learningGoals || [];
      
      // Extract videos based on user interests
      let interestVideos: any[] = [];
      
      subjects.forEach((subject: string) => {
        const subjectKey = subject.toLowerCase().replace(/\s+/g, '').replace(/&/, '');
        if (YOUTUBE_SEARCH_RESULTS[subjectKey as keyof typeof YOUTUBE_SEARCH_RESULTS]) {
          interestVideos.push(...YOUTUBE_SEARCH_RESULTS[subjectKey as keyof typeof YOUTUBE_SEARCH_RESULTS]);
        }
      });

      goals.forEach((goal: string) => {
        const goalKey = goal.toLowerCase().replace(/\s+/g, '');
        Object.keys(YOUTUBE_SEARCH_RESULTS).forEach(key => {
          if (goalKey.includes(key) || key.includes(goalKey.substring(0, 4))) {
            interestVideos.push(...YOUTUBE_SEARCH_RESULTS[key as keyof typeof YOUTUBE_SEARCH_RESULTS]);
          }
        });
      });

      // Remove duplicates and set
      const uniqueVideos = interestVideos.filter((video, index, self) => 
        index === self.findIndex(v => v.id === video.id)
      );
      
      setUserInterestVideos(uniqueVideos.slice(0, 6)); // Limit to 6 videos
    }
  };

  const initializeCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: "user",
          width: { ideal: 640 },
          height: { ideal: 480 }
        }
      });
      
      setCameraStream(stream);
      setIsCameraActive(true);
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }

      // Start face detection
      startFaceDetection();
    } catch (error) {
      console.error("Camera access denied:", error);
      setIsCameraActive(false);
      // Fallback to simulation if camera access fails
      startSimulatedDetection();
    }
  };

  const startFaceDetection = () => {
    const detectFace = () => {
      if (!videoRef.current || !canvasRef.current || !isCameraActive) return;

      const video = videoRef.current;
      const canvas = canvasRef.current;
      const ctx = canvas.getContext('2d');

      if (!ctx || video.videoWidth === 0) return;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      // Simple face detection simulation based on video feed
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const data = imageData.data;
      
      // Basic face detection: look for skin-tone pixels in center area
      let facePixels = 0;
      let totalPixels = 0;
      const centerX = canvas.width / 2;
      const centerY = canvas.height / 2;
      const faceArea = Math.min(canvas.width, canvas.height) * 0.3;

      for (let y = centerY - faceArea/2; y < centerY + faceArea/2; y += 5) {
        for (let x = centerX - faceArea/2; x < centerX + faceArea/2; x += 5) {
          if (x >= 0 && x < canvas.width && y >= 0 && y < canvas.height) {
            const i = (Math.floor(y) * canvas.width + Math.floor(x)) * 4;
            const r = data[i];
            const g = data[i + 1];
            const b = data[i + 2];
            
            // Detect skin-tone pixels (rough approximation)
            if (r > 95 && g > 40 && b > 20 && r > g && r > b && 
                Math.abs(r - g) > 15 && r - b > 15) {
              facePixels++;
            }
            totalPixels++;
          }
        }
      }

      const faceRatio = totalPixels > 0 ? facePixels / totalPixels : 0;
      const faceDetectedNow = faceRatio > 0.1; // At least 10% skin-tone pixels
      
      setFaceDetected(faceDetectedNow);
      setEyesOpen(faceDetectedNow); // Simplified: assume eyes open if face detected
      setLookingAtCenter(faceDetectedNow && Math.random() > 0.3); // 70% chance if face detected

      // Calculate attention based on detection
      let attention = 0;
      if (faceDetectedNow) {
        if (lookingAtCenter) {
          attention = Math.floor(Math.random() * 30) + 70; // 70-100% when looking at center
        } else {
          attention = Math.floor(Math.random() * 40) + 30; // 30-70% when face detected but not centered
        }
      } else {
        attention = Math.floor(Math.random() * 30) + 5; // 5-35% when no face
      }

      setCurrentAttention(attention);
      setIsLookingAtScreen(faceDetectedNow && lookingAtCenter);

      // Handle focus alerts
      handleFocusAlerts(attention);
    };

    const interval = setInterval(detectFace, 2000); // Check every 2 seconds
    return () => clearInterval(interval);
  };

  const startSimulatedDetection = () => {
    const interval = setInterval(() => {
      // Fallback simulation if camera doesn't work
      const lookingAway = Math.random() < 0.2; // 20% chance of looking away
      let attentionScore;
      
      if (!lookingAway) {
        attentionScore = Math.floor(Math.random() * 30) + 70; // 70-100% when focused
      } else {
        attentionScore = Math.floor(Math.random() * 40) + 10; // 10-50% when not looking
      }
      
      setCurrentAttention(attentionScore);
      setIsLookingAtScreen(!lookingAway);
      setFaceDetected(!lookingAway);
      
      handleFocusAlerts(attentionScore);
    }, 3000);

    return () => clearInterval(interval);
  };

  const handleFocusAlerts = (attentionScore: number) => {
    const currentTime = Date.now();
    
    // Sound alerts based on focus level with proper timing
    if (soundEnabled && currentTime - lastSoundTime > 5000) { // 5 second cooldown
      if (attentionScore < 25) {
        // Critical attention - peep sound
        AudioUtils.playPeepSound();
        setLastSoundTime(currentTime);
        setConsecutiveLowFocus(prev => prev + 1);
        
        // Show concentration video after 2 consecutive critical readings
        if (consecutiveLowFocus >= 2) {
          setShowConcentrationVideo(true);
          if (isVideoPlaying) setIsVideoPlaying(false);
        }
      } else if (attentionScore < 50) {
        // Moderate attention - pop sound
        AudioUtils.playPopSound();
        setLastSoundTime(currentTime);
        setConsecutiveLowFocus(prev => prev + 1);
        
        // Show focus exercise after 2 consecutive moderate readings
        if (consecutiveLowFocus >= 2) {
          setShowFocusExercise(true);
        }
      } else {
        // Good attention - reset counters
        setConsecutiveLowFocus(0);
      }
    }

    // Update focus session
    if (focusSession) {
      setFocusSession(prev => prev ? {
        ...prev,
        averageAttention: Math.round((prev.averageAttention + attentionScore) / 2),
        distractions: attentionScore < 30 ? prev.distractions + 1 : prev.distractions
      } : null);
    }
  };

  // Watch time tracking with target completion
  useEffect(() => {
    if (isVideoPlaying && currentAttention > 30) { // Only count watch time if paying attention
      const interval = setInterval(() => {
        setWatchTime(prev => prev + 1);
        setVideoProgress(prev => Math.min(prev + 1, 100));
        
        // Update user progress
        setUserProgress(prev => {
          const updated = {
            ...prev,
            totalWatchTime: prev.totalWatchTime + 1,
            lastWatched: new Date().toISOString(),
            attentionScore: currentAttention
          };
          localStorage.setItem(`progress_${courseId}`, JSON.stringify(updated));
          return updated;
        });

        // Check target completion
        if (currentTarget.type === "watch_time" && watchTime + 1 >= currentTarget.goal * 60) {
          setCurrentTarget(prev => ({ ...prev, current: watchTime + 1, completed: true }));
          setShowTargetPopup(true);
          
          // Play success sound
          if (soundEnabled) {
            AudioUtils.playSuccessSound();
          }
          
          // Update user progress
          setUserProgress(prev => {
            const updated = { ...prev, targetsMet: prev.targetsMet + 1 };
            localStorage.setItem(`progress_${courseId}`, JSON.stringify(updated));
            return updated;
          });
        }
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [isVideoPlaying, watchTime, currentTarget, courseId, currentAttention]);

  const submitVideoRequest = () => {
    if (newVideoRequest.title && newVideoRequest.subject) {
      const request: VideoRequest = {
        id: Date.now().toString(),
        ...newVideoRequest,
        requestedBy: "Current User",
        approved: false
      };
      
      const updatedRequests = [...videoRequests, request];
      setVideoRequests(updatedRequests);
      localStorage.setItem("video_requests", JSON.stringify(updatedRequests));
      
      // Search for matching video from user interests
      const matchingVideos = userInterestVideos.filter(video => 
        video.title.toLowerCase().includes(newVideoRequest.title.toLowerCase()) ||
        video.description.toLowerCase().includes(newVideoRequest.subject.toLowerCase())
      );
      
      // Auto-approve with actual YouTube video if found
      setTimeout(() => {
        const videoToUse = matchingVideos.length > 0 ? matchingVideos[0] : userInterestVideos[0];
        const approvedRequest = {
          ...request,
          approved: true,
          youtubeId: videoToUse?.id || "dQw4w9WgXcQ",
          thumbnail: videoToUse?.thumbnail || `https://img.youtube.com/vi/dQw4w9WgXcQ/maxresdefault.jpg`,
          duration: videoToUse?.duration || "15:30"
        };
        
        const finalRequests = updatedRequests.map(r => 
          r.id === request.id ? approvedRequest : r
        );
        setVideoRequests(finalRequests);
        localStorage.setItem("video_requests", JSON.stringify(finalRequests));
      }, 2000);
      
      setNewVideoRequest({ title: "", subject: "", description: "" });
      setShowVideoRequest(false);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Hidden video and canvas for face detection */}
      <div className="hidden">
        <video ref={videoRef} autoPlay muted width="640" height="480" />
        <canvas ref={canvasRef} width="640" height="480" />
      </div>

      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Dashboard
              </Button>
              <div className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-xl">
                  <BookOpen className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h1 className="text-xl font-bold">Smart Learning Interface</h1>
                  <p className="text-sm text-muted-foreground">
                    Real camera detection & interest-based videos
                  </p>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {/* Camera Status */}
              <div className="flex items-center gap-2 px-3 py-2 bg-background/60 rounded-lg border">
                {isCameraActive ? (
                  <Camera className="h-4 w-4 text-green-600" />
                ) : (
                  <CameraOff className="h-4 w-4 text-red-600" />
                )}
                <span className="text-sm font-medium">
                  {isCameraActive ? "Camera Active" : "Camera Off"}
                </span>
              </div>

              {/* Sound toggle */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => setSoundEnabled(!soundEnabled)}
                className="gap-2"
              >
                {soundEnabled ? <Volume2 className="h-4 w-4" /> : <VolumeX className="h-4 w-4" />}
                {soundEnabled ? "Sound On" : "Sound Off"}
              </Button>

              {/* Attention Status */}
              <div className="flex items-center gap-2 px-3 py-2 bg-background/60 rounded-lg border">
                <Eye className={`h-4 w-4 ${currentAttention >= 70 ? 'text-green-600' : currentAttention >= 50 ? 'text-yellow-600' : 'text-red-600'}`} />
                <span className={`text-sm font-medium ${currentAttention >= 70 ? 'text-green-600' : currentAttention >= 50 ? 'text-yellow-600' : 'text-red-600'}`}>
                  {currentAttention}%
                </span>
                <Badge variant={isLookingAtScreen ? "default" : "destructive"} size="sm">
                  {isLookingAtScreen ? "Focused" : "Away"}
                </Badge>
              </div>

              <Button variant="outline" size="sm" onClick={() => navigate("/settings")} className="gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-4 gap-6">
          {/* Main Content Area */}
          <div className="lg:col-span-3 space-y-6">
            {/* Current Target */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Current Target
                  </div>
                  {currentTarget.completed && (
                    <Badge variant="default" className="gap-1">
                      <CheckCircle className="h-3 w-3" />
                      Completed!
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Watch {currentTarget.goal} minutes with focus</span>
                    <span className="font-medium">{formatTime(watchTime)}</span>
                  </div>
                  <Progress value={(watchTime / (currentTarget.goal * 60)) * 100} className="h-3" />
                  <div className="flex items-center justify-between text-sm text-muted-foreground">
                    <span>Progress: {Math.round((watchTime / (currentTarget.goal * 60)) * 100)}%</span>
                    <span>Goal: {currentTarget.goal} minutes</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Video Player */}
            <Card>
              <CardContent className="p-0">
                <div className="relative bg-black rounded-t-lg overflow-hidden aspect-video">
                  {isVideoPlaying ? (
                    <div className="bg-gradient-to-br from-slate-800 to-slate-900 h-full flex flex-col">
                      <div className="flex-1 p-8">
                        <div className="bg-slate-700 rounded-lg p-6 mb-4">
                          <h3 className="text-white text-xl mb-2">Interest-Based Learning Content</h3>
                          <div className="text-slate-300 text-sm space-y-2">
                            <p>Personalized content based on your subjects and goals</p>
                            <p>Watch time: {formatTime(watchTime)}</p>
                            <p>Real-time attention: {currentAttention}%</p>
                            <p>Face detected: {faceDetected ? 'Yes' : 'No'}</p>
                          </div>
                        </div>
                        <div className="bg-blue-600 rounded p-4">
                          <p className="text-white font-mono text-sm">
                            // This content matches your learning interests
                            <br />
                            // Real camera-based focus detection is active
                            <br />
                            // Only focused watch time counts toward your goal
                          </p>
                        </div>
                      </div>

                      <div className="bg-black/50 p-4">
                        <div className="flex items-center gap-4 text-white text-sm">
                          <span>{formatTime(watchTime)}</span>
                          <div className="flex-1 bg-gray-600 h-1 rounded">
                            <div className="bg-red-500 h-1 rounded transition-all duration-200" style={{ width: `${videoProgress}%` }}></div>
                          </div>
                          <span>Live • Focus: {currentAttention}%</span>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
                      <div className="text-center text-white">
                        <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                          <Play className="h-10 w-10 ml-1" />
                        </div>
                        <p className="text-xl font-medium mb-2">Start Interest-Based Learning</p>
                        <p className="text-sm opacity-75 mb-4">Camera-powered focus detection ready</p>
                        <div className="text-xs opacity-60">
                          <p>Videos selected based on your profile interests</p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                <div className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <Button
                        onClick={() => setIsVideoPlaying(!isVideoPlaying)}
                        className="gap-2"
                      >
                        {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        {isVideoPlaying ? "Pause" : "Play"}
                      </Button>

                      <Button
                        onClick={() => setShowVideoRequest(true)}
                        variant="outline"
                        className="gap-2"
                      >
                        <Search className="h-4 w-4" />
                        Request Video
                      </Button>
                    </div>

                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      Total focused time: {formatTime(userProgress.totalWatchTime)}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Interest-Based Video Recommendations */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Youtube className="h-5 w-5" />
                  Your Interest-Based Videos
                </CardTitle>
                <CardDescription>Videos curated from YouTube based on your learning interests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {userInterestVideos.length > 0 ? (
                    userInterestVideos.map((video) => (
                      <div
                        key={video.id}
                        className="flex gap-3 p-3 border rounded-lg hover:bg-accent/50 transition-all cursor-pointer"
                        onClick={() => {
                          window.open(`https://youtube.com/watch?v=${video.id}`, '_blank');
                        }}
                      >
                        <img
                          src={video.thumbnail}
                          alt={video.title}
                          className="w-20 h-12 object-cover rounded"
                        />
                        <div className="flex-1 min-w-0">
                          <h4 className="font-medium text-sm line-clamp-2">{video.title}</h4>
                          <p className="text-xs text-muted-foreground mt-1">{video.duration}</p>
                          <p className="text-xs text-muted-foreground line-clamp-1 mt-1">{video.description}</p>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="col-span-2 text-center py-6">
                      <Youtube className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                      <p className="text-muted-foreground">Loading videos based on your interests...</p>
                      <Button
                        onClick={() => setShowVideoRequest(true)}
                        variant="outline"
                        size="sm"
                        className="mt-3 gap-2"
                      >
                        <Search className="h-4 w-4" />
                        Request Specific Video
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Requested Videos */}
            {videoRequests.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Search className="h-5 w-5" />
                    Your Video Requests
                  </CardTitle>
                  <CardDescription>Videos you've requested and their approval status</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {videoRequests.map((request) => (
                      <div key={request.id} className="flex items-center justify-between p-3 border rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium">{request.title}</h4>
                          <p className="text-sm text-muted-foreground">{request.subject}</p>
                          <p className="text-xs text-muted-foreground mt-1">{request.description}</p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant={request.approved ? "default" : "secondary"}>
                            {request.approved ? "Approved" : "Processing..."}
                          </Badge>
                          {request.approved && request.youtubeId && (
                            <Button
                              size="sm"
                              onClick={() => {
                                window.open(`https://youtube.com/watch?v=${request.youtubeId}`, '_blank');
                              }}
                              className="gap-1"
                            >
                              <Play className="h-3 w-3" />
                              Watch
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Real-Time Focus Detection */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Eye className="h-5 w-5" />
                  Live Focus Detection
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${currentAttention >= 70 ? 'text-green-600' : currentAttention >= 50 ? 'text-yellow-600' : 'text-red-600'}`}>
                      {currentAttention}%
                    </div>
                    <p className="text-sm text-muted-foreground">Real-time Attention</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Face Detected:</span>
                      <Badge variant={faceDetected ? "default" : "destructive"} size="sm">
                        {faceDetected ? "Yes" : "No"}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Looking at Screen:</span>
                      <Badge variant={isLookingAtScreen ? "default" : "destructive"} size="sm">
                        {isLookingAtScreen ? "Yes" : "No"}
                      </Badge>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Camera Status:</span>
                      <Badge variant={isCameraActive ? "default" : "secondary"} size="sm">
                        {isCameraActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </div>

                  {focusSession && (
                    <div className="space-y-2 pt-3 border-t">
                      <div className="flex justify-between text-sm">
                        <span>Session Average:</span>
                        <span className="font-medium">{focusSession.averageAttention}%</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Distractions:</span>
                        <span className="font-medium">{focusSession.distractions}</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Session Time:</span>
                        <span className="font-medium">{formatTime(Math.floor((Date.now() - focusSession.startTime) / 1000))}</span>
                      </div>
                    </div>
                  )}

                  {/* Focus alerts */}
                  {currentAttention < 25 && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg animate-pulse">
                      <div className="flex items-center gap-2 text-red-800">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-sm font-medium">Critical Focus Alert!</span>
                      </div>
                      <p className="text-xs text-red-600 mt-1">
                        Very low attention. Sound alert triggered.
                      </p>
                    </div>
                  )}

                  {currentAttention >= 25 && currentAttention < 50 && (
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <div className="flex items-center gap-2 text-orange-800">
                        <Eye className="h-4 w-4" />
                        <span className="text-sm font-medium">Focus Exercise Needed</span>
                      </div>
                      <p className="text-xs text-orange-600 mt-1">
                        Moderate attention. Pop sound played.
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Progress Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Your Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Focused Watch Time</span>
                      <span>{formatTime(userProgress.totalWatchTime)}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Targets Met</span>
                      <span>{userProgress.targetsMet}</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Average Attention</span>
                      <span>{Math.round(userProgress.attentionScore)}%</span>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Interest Videos</span>
                      <span>{userInterestVideos.length} available</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Target Completion Popup */}
      {showTargetPopup && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-md w-full animate-in slide-in-from-bottom-4 duration-500">
            <div className="p-6 border-b bg-gradient-to-r from-green-50 to-emerald-50">
              <div className="text-center">
                <div className="w-16 h-16 bg-green-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <Trophy className="h-8 w-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold text-green-800 mb-2">Target Achieved!</h3>
                <p className="text-green-600">
                  You've completed your {currentTarget.goal}-minute focused learning target!
                </p>
              </div>
            </div>

            <div className="p-6">
              <div className="text-center space-y-4">
                <div className="grid grid-cols-2 gap-4 text-center">
                  <div>
                    <p className="text-2xl font-bold text-primary">{formatTime(watchTime)}</p>
                    <p className="text-xs text-muted-foreground">Focused Time</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-green-600">{focusSession?.averageAttention || 0}%</p>
                    <p className="text-xs text-muted-foreground">Avg. Attention</p>
                  </div>
                </div>
                <Button onClick={() => setShowTargetPopup(false)} className="w-full gap-2">
                  <CheckCircle className="h-4 w-4" />
                  Continue Learning
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Video Request Modal */}
      {showVideoRequest && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-md w-full">
            <div className="p-6 border-b">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">Request Interest-Based Video</h3>
                <Button variant="ghost" size="sm" onClick={() => setShowVideoRequest(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-2">
                We'll find YouTube videos matching your interests and learning goals
              </p>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <Label>Video Topic</Label>
                <Input
                  value={newVideoRequest.title}
                  onChange={(e) => setNewVideoRequest(prev => ({ ...prev, title: e.target.value }))}
                  placeholder="e.g., Introduction to Calculus"
                />
              </div>
              <div>
                <Label>Subject Area</Label>
                <Input
                  value={newVideoRequest.subject}
                  onChange={(e) => setNewVideoRequest(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="e.g., Mathematics, Science, English"
                />
              </div>
              <div>
                <Label>Additional Details (Optional)</Label>
                <Textarea
                  value={newVideoRequest.description}
                  onChange={(e) => setNewVideoRequest(prev => ({ ...prev, description: e.target.value }))}
                  placeholder="Any specific aspects you want to learn about..."
                  rows={3}
                />
              </div>

              <div className="flex gap-3">
                <Button variant="outline" onClick={() => setShowVideoRequest(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={submitVideoRequest} className="flex-1 gap-2">
                  <Youtube className="h-4 w-4" />
                  Find Video
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Focus Exercise Modal (25-50% attention) */}
      {showFocusExercise && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-lg w-full">
            <div className="p-6 border-b bg-gradient-to-r from-orange-50 to-yellow-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-full">
                    <Zap className="h-6 w-6 text-orange-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-orange-800">Focus Exercise</h3>
                    <p className="text-sm text-orange-600">
                      Attention at {currentAttention}% - Let's improve it!
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setShowFocusExercise(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="p-6">
              <div className="text-center space-y-6">
                <div className="relative h-48 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border-2 border-dashed border-blue-200 flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0">
                    <div className="w-4 h-4 bg-blue-500 rounded-full absolute animate-ping"
                         style={{
                           animation: "moveAroundScreen 6s infinite linear",
                           transformOrigin: "center"
                         }}>
                    </div>
                  </div>
                  <div className="text-center z-10 bg-white/80 p-4 rounded-lg">
                    <Eye className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                    <p className="font-medium text-blue-800">Follow the moving dot</p>
                    <p className="text-sm text-blue-600">Train your visual attention</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <Button variant="outline" onClick={() => setShowFocusExercise(false)} className="flex-1">
                    Skip Exercise
                  </Button>
                  <Button 
                    onClick={() => {
                      if (soundEnabled) AudioUtils.playPopSound();
                      setShowFocusExercise(false);
                      setConsecutiveLowFocus(0);
                    }} 
                    className="flex-1 gap-2"
                  >
                    <CheckCircle className="h-4 w-4" />
                    Complete
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Concentration Video Modal (<25% attention) */}
      {showConcentrationVideo && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full">
            <div className="p-6 border-b bg-gradient-to-r from-red-50 to-orange-50">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-red-100 rounded-full animate-pulse">
                    <AlertTriangle className="h-6 w-6 text-red-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-red-800">Critical Attention Alert!</h3>
                    <p className="text-sm text-red-600">
                      Focus at {currentAttention}% - Watch a concentration video from YouTube
                    </p>
                  </div>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setShowConcentrationVideo(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>

            <div className="p-6 space-y-4">
              {concentrationVideos.map((video, index) => (
                <div
                  key={video.id}
                  className="flex gap-4 p-4 border rounded-xl hover:bg-accent/50 transition-all cursor-pointer"
                  onClick={() => {
                    window.open(`https://youtube.com/watch?v=${video.id}`, '_blank');
                    if (soundEnabled) AudioUtils.playPeepSound();
                    setShowConcentrationVideo(false);
                    setConsecutiveLowFocus(0);
                  }}
                >
                  <img
                    src={video.thumbnail}
                    alt={video.title}
                    className="w-24 h-16 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <h4 className="font-semibold text-sm mb-1">{video.title}</h4>
                    <p className="text-xs text-muted-foreground mb-2">{video.description}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {video.duration}
                      <Youtube className="h-3 w-3" />
                      Real YouTube Video
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 border-t bg-red-50/50">
              <div className="flex items-center justify-between">
                <p className="text-sm text-red-800">
                  Choose a YouTube video to restore your concentration
                </p>
                <Button
                  onClick={() => {
                    setShowConcentrationVideo(false);
                    setConsecutiveLowFocus(0);
                  }}
                  variant="outline"
                >
                  Maybe Later
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
