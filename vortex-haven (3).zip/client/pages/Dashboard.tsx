import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import * as faceapi from "face-api.js";
// @ts-ignore
import * as webgazer from "webgazer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Brain, Camera, Eye, Heart, Activity, TrendingUp, BookOpen, Target, Settings, Play, Clock, Youtube, X, ExternalLink, Pause, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";

interface EmotionData {
  expression: string;
  confidence: number;
  timestamp: number;
}

interface AttentionData {
  focused: boolean;
  gazeDirection: string;
  blinkRate: number;
  timestamp: number;
}

interface LearningSession {
  topic: string;
  duration: number;
  engagementScore: number;
  emotionalState: string;
  completionRate: number;
}

interface Course {
  id: string;
  title: string;
  description: string;
  progress: number;
  duration: string;
  difficulty: string;
  nextLesson: string;
}

export default function Dashboard() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isModelLoaded, setIsModelLoaded] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [emotions, setEmotions] = useState<EmotionData[]>([]);
  const [attention, setAttention] = useState<AttentionData | null>(null);
  const [currentEmotion, setCurrentEmotion] = useState<string>("neutral");
  const [engagementScore, setEngagementScore] = useState(75);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [cameraStatus, setCameraStatus] = useState<"idle" | "requesting" | "granted" | "denied">("idle");
  const [showVideoSuggestions, setShowVideoSuggestions] = useState(false);
  const [lowConfidenceCount, setLowConfidenceCount] = useState(0);

  // Eye tracking and attention states
  const [isEyeTrackingActive, setIsEyeTrackingActive] = useState(false);
  const [attentionLevel, setAttentionLevel] = useState(75);
  const [isLookingAtScreen, setIsLookingAtScreen] = useState(true);
  const [lowAttentionCount, setLowAttentionCount] = useState(0);
  const [showAttentionVideo, setShowAttentionVideo] = useState(false);
  const [currentAttentionVideo, setCurrentAttentionVideo] = useState(0);
  const [isVideoPlaying, setIsVideoPlaying] = useState(false);
  const [awayFromScreenTime, setAwayFromScreenTime] = useState(0);

  const navigate = useNavigate();

  // Mock user data
  const [userName] = useState("Alex");
  const [todayFocus] = useState(87);
  const [weeklyProgress] = useState(68);
  const [streakDays] = useState(12);

  // Mock learning sessions data
  const [learningSessions] = useState<LearningSession[]>([
    { topic: "Machine Learning Basics", duration: 45, engagementScore: 87, emotionalState: "focused", completionRate: 92 },
    { topic: "Neural Networks", duration: 60, engagementScore: 94, emotionalState: "happy", completionRate: 88 },
    { topic: "Data Structures", duration: 30, engagementScore: 76, emotionalState: "neutral", completionRate: 95 },
  ]);

  // Mock YouTube video suggestions for low confidence emotions
  const [videoSuggestions] = useState([
    {
      id: "1",
      title: "10 Minute Meditation for Focus and Clarity",
      thumbnail: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=320&h=180&fit=crop",
      channel: "Mindful Learning",
      duration: "10:23",
      views: "2.1M views"
    },
    {
      id: "2",
      title: "Quick Breathing Exercises to Reduce Stress",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=320&h=180&fit=crop",
      channel: "Wellness Hub",
      duration: "5:47",
      views: "892K views"
    },
    {
      id: "3",
      title: "Study Music for Deep Focus - Brain Waves",
      thumbnail: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=320&h=180&fit=crop",
      channel: "Focus Sounds",
      duration: "60:00",
      views: "5.3M views"
    },
    {
      id: "4",
      title: "5 Minute Energy Boost - Quick Exercise",
      thumbnail: "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=320&h=180&fit=crop",
      channel: "Active Learning",
      duration: "5:12",
      views: "1.4M views"
    }
  ]);

  // Attention training videos that play when focus is low
  const [attentionVideos] = useState([
    {
      id: "attention-1",
      title: "Focus Enhancement Exercise",
      description: "A quick 2-minute exercise to improve your concentration",
      content: "Follow the moving dot with your eyes to train your attention...",
      duration: 120, // 2 minutes
      type: "eye-exercise"
    },
    {
      id: "attention-2",
      title: "Breathing Focus Technique",
      description: "Deep breathing to restore mental clarity",
      content: "Take slow, deep breaths while watching the visualization...",
      duration: 180, // 3 minutes
      type: "breathing"
    },
    {
      id: "attention-3",
      title: "Visual Attention Training",
      description: "Track objects to improve visual attention",
      content: "Follow the colored shapes as they move across the screen...",
      duration: 150, // 2.5 minutes
      type: "visual-tracking"
    }
  ]);

  // Mock recommended courses
  const [recommendedCourses] = useState<Course[]>([
    {
      id: "1",
      title: "Advanced React Patterns",
      description: "Learn advanced React patterns and optimization techniques",
      progress: 65,
      duration: "4h 20m",
      difficulty: "Intermediate",
      nextLesson: "Custom Hooks Deep Dive"
    },
    {
      id: "2", 
      title: "Machine Learning Fundamentals",
      description: "Introduction to ML concepts and practical applications",
      progress: 23,
      duration: "6h 15m",
      difficulty: "Beginner",
      nextLesson: "Linear Regression Basics"
    },
    {
      id: "3",
      title: "System Design Interview Prep",
      description: "Master system design concepts for technical interviews",
      progress: 0,
      duration: "8h 45m", 
      difficulty: "Advanced",
      nextLesson: "Scalability Fundamentals"
    }
  ]);

  // Load face-api.js models and initialize eye tracking
  useEffect(() => {
    const loadModels = async () => {
      try {
        await Promise.all([
          faceapi.nets.tinyFaceDetector.loadFromUri('/models'),
          faceapi.nets.faceLandmark68Net.loadFromUri('/models'),
          faceapi.nets.faceRecognitionNet.loadFromUri('/models'),
          faceapi.nets.faceExpressionNet.loadFromUri('/models'),
        ]);
        setIsModelLoaded(true);
      } catch (error) {
        console.log("Models not found, continuing with mock data");
        setIsModelLoaded(true);
      }
    };
    loadModels();

    // Initialize WebGazer for eye tracking
    initializeEyeTracking();
  }, []);

  // Initialize eye tracking
  const initializeEyeTracking = async () => {
    try {
      console.log("Initializing eye tracking...");

      await webgazer.setGazeListener((data: any, timestamp: number) => {
        if (data) {
          // Calculate if user is looking at screen center
          const screenCenterX = window.innerWidth / 2;
          const screenCenterY = window.innerHeight / 2;
          const distanceFromCenter = Math.sqrt(
            Math.pow(data.x - screenCenterX, 2) + Math.pow(data.y - screenCenterY, 2)
          );

          // Consider user looking at screen if gaze is within reasonable bounds
          const maxDistance = Math.min(window.innerWidth, window.innerHeight) * 0.4;
          const lookingAtScreen = distanceFromCenter < maxDistance;

          setIsLookingAtScreen(lookingAtScreen);

          // Calculate attention level based on gaze stability and screen focus
          const attentionScore = lookingAtScreen ?
            Math.max(20, 100 - (distanceFromCenter / maxDistance) * 80) : 10;

          setAttentionLevel(Math.floor(attentionScore));
        }
      }).begin();

      webgazer.showVideoPreview(false)
        .showPredictionPoints(false)
        .applyKalmanFilter(true);

      setIsEyeTrackingActive(true);
      console.log("Eye tracking initialized successfully");

    } catch (error) {
      console.error("Eye tracking initialization failed:", error);
      // Start mock eye tracking for demo
      startMockEyeTracking();
    }
  };

  // Mock eye tracking for demo purposes
  const startMockEyeTracking = () => {
    setIsEyeTrackingActive(true);

    const mockEyeTracking = setInterval(() => {
      // Simulate varying attention levels
      const randomAttention = Math.random() * 100;
      const lookingAway = Math.random() < 0.2; // 20% chance of looking away

      setAttentionLevel(Math.floor(randomAttention));
      setIsLookingAtScreen(!lookingAway);

      // Track low attention periods
      if (randomAttention < 50) {
        setLowAttentionCount(prev => {
          const newCount = prev + 1;
          if (newCount >= 3 && !showAttentionVideo) {
            setShowAttentionVideo(true);
            setCurrentAttentionVideo(Math.floor(Math.random() * attentionVideos.length));
          }
          return newCount;
        });
      } else {
        setLowAttentionCount(0);
      }

      // Track time away from screen
      if (lookingAway) {
        setAwayFromScreenTime(prev => {
          const newTime = prev + 1;
          // If away for more than 5 seconds and video is playing, pause and redirect
          if (newTime >= 5 && isVideoPlaying) {
            setIsVideoPlaying(false);
            setTimeout(() => navigate('/dashboard'), 1000);
          }
          return newTime;
        });
      } else {
        setAwayFromScreenTime(0);
      }
    }, 1000);

    return () => clearInterval(mockEyeTracking);
  };

  // Start webcam with improved permission handling
  const startCamera = async () => {
    setCameraStatus("requesting");

    try {
      // Check for camera support
      if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error("Camera not supported in this browser");
      }

      // Check for camera permissions first
      try {
        const permissionResult = await navigator.permissions?.query({ name: 'camera' as PermissionName });
        console.log("Camera permission status:", permissionResult?.state);
      } catch (permError) {
        console.log("Permission API not supported");
      }

      console.log("Requesting camera access...");

      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 320, max: 640 },
          height: { ideal: 240, max: 480 },
          facingMode: "user",
          frameRate: { ideal: 15, max: 30 }
        },
        audio: false
      });

      console.log("Camera stream obtained successfully");

      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.muted = true;
        videoRef.current.playsInline = true;

        // Wait for metadata to load
        await new Promise((resolve, reject) => {
          if (!videoRef.current) return reject(new Error("Video element not found"));

          videoRef.current.onloadedmetadata = () => {
            console.log("Video metadata loaded");
            resolve(true);
          };

          videoRef.current.onerror = (error) => {
            console.error("Video error:", error);
            reject(error);
          };

          // Timeout after 5 seconds
          setTimeout(() => reject(new Error("Video load timeout")), 5000);
        });

        // Play the video
        await videoRef.current.play();
        console.log("Video playing successfully");

        setCameraStatus("granted");
        setIsCameraActive(true);
        setIsAnalyzing(true);
        startFaceDetection();

      } else {
        throw new Error("Video element not available");
      }
    } catch (error: any) {
      console.error("Camera access error:", error);

      let errorMessage = "Unable to access camera. ";
      if (error.name === "NotAllowedError") {
        errorMessage += "Please allow camera access and try again.";
      } else if (error.name === "NotFoundError") {
        errorMessage += "No camera found on this device.";
      } else if (error.name === "NotReadableError") {
        errorMessage += "Camera is busy or unavailable.";
      } else if (error.name === "OverconstrainedError") {
        errorMessage += "Camera constraints not supported.";
      } else {
        errorMessage += error.message || "Unknown error occurred.";
      }

      // Show user-friendly error message
      alert(errorMessage + " Starting with demo mode.");

      setCameraStatus("denied");
      startMockAnalysis();
    }
  };

  // Start mock analysis for demo purposes
  const startMockAnalysis = () => {
    setIsAnalyzing(true);

    const emotions = ["happy", "focused", "neutral", "surprised", "sad", "frustrated"];
    const mockInterval = setInterval(() => {
      const randomEmotion = emotions[Math.floor(Math.random() * emotions.length)];
      // Simulate varying confidence levels (sometimes below 50%)
      const confidence = Math.random() * 0.8 + 0.2; // 20% to 100%

      setCurrentEmotion(randomEmotion);

      // Track low confidence emotions
      if (confidence < 0.5) {
        setLowConfidenceCount(prev => {
          const newCount = prev + 1;
          // Show video suggestions after 2 consecutive low confidence readings
          if (newCount >= 2 && !showVideoSuggestions) {
            setShowVideoSuggestions(true);
          }
          return newCount;
        });
      } else {
        setLowConfidenceCount(0);
        if (confidence > 0.7 && showVideoSuggestions) {
          // Hide suggestions when confidence improves
          setTimeout(() => setShowVideoSuggestions(false), 3000);
        }
      }

      setEmotions(prev => [...prev.slice(-5), {
        expression: randomEmotion,
        confidence,
        timestamp: Date.now()
      }]);

      setAttention({
        focused: confidence > 0.6, // Link focus to confidence
        gazeDirection: Math.random() > 0.5 ? "center" : "away",
        blinkRate: Math.random() * 20 + 10,
        timestamp: Date.now()
      });
    }, 3000);

    setTimeout(() => clearInterval(mockInterval), 60000);
  };

  // Face detection loop
  const startFaceDetection = async () => {
    if (!videoRef.current || !canvasRef.current) return;

    const detectFaces = async () => {
      if (!videoRef.current || !canvasRef.current || !isAnalyzing) return;

      try {
        const detections = await faceapi
          .detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions())
          .withFaceLandmarks()
          .withFaceExpressions();

        if (detections.length > 0) {
          const expressions = detections[0].expressions;
          const dominantExpression = Object.keys(expressions).reduce((a, b) =>
            expressions[a as keyof typeof expressions] > expressions[b as keyof typeof expressions] ? a : b
          );

          const confidence = expressions[dominantExpression as keyof typeof expressions];

          setCurrentEmotion(dominantExpression);

          // Track low confidence emotions for video suggestions
          if (confidence < 0.5) {
            setLowConfidenceCount(prev => {
              const newCount = prev + 1;
              if (newCount >= 2 && !showVideoSuggestions) {
                setShowVideoSuggestions(true);
              }
              return newCount;
            });
          } else {
            setLowConfidenceCount(0);
            if (confidence > 0.7 && showVideoSuggestions) {
              setTimeout(() => setShowVideoSuggestions(false), 3000);
            }
          }

          setEmotions(prev => [...prev.slice(-5), {
            expression: dominantExpression,
            confidence,
            timestamp: Date.now()
          }]);
        }
      } catch (error) {
        console.error("Face detection error:", error);
      }

      setTimeout(detectFaces, 2000);
    };

    detectFaces();
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setIsCameraActive(false);
    setIsAnalyzing(false);
    setCameraStatus("idle");
  };

  const getEmotionColor = (emotion: string) => {
    switch (emotion) {
      case "happy": return "text-emotion-happy bg-emotion-happy/10";
      case "sad": return "text-emotion-sad bg-emotion-sad/10";
      case "angry": return "text-emotion-angry bg-emotion-angry/10";
      case "surprised": return "text-emotion-surprised bg-emotion-surprised/10";
      case "focused": return "text-emotion-focused bg-emotion-focused/10";
      default: return "text-emotion-neutral bg-emotion-neutral/10";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800";
      case "Intermediate": return "bg-yellow-100 text-yellow-800";
      case "Advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-neural-50 to-neural-100">
      {/* Header */}
      <header className="border-b bg-background/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Link to="/" className="flex items-center gap-3">
                <div className="p-2 bg-primary/10 rounded-xl">
                  <Brain className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-neural-600 bg-clip-text text-transparent">
                    NeuroLearn AI
                  </h1>
                  <p className="text-sm text-muted-foreground">Welcome back, {userName}!</p>
                </div>
              </Link>
            </div>
            <div className="flex items-center gap-4">
              <Badge variant="secondary" className="gap-2">
                <Activity className="h-4 w-4" />
                {isAnalyzing ? "Analyzing" : "Ready"}
              </Badge>
              {cameraStatus !== "idle" && (
                <Badge 
                  variant={cameraStatus === "granted" ? "default" : cameraStatus === "requesting" ? "secondary" : "destructive"}
                  className="gap-2"
                >
                  <Camera className="h-4 w-4" />
                  {cameraStatus === "granted" ? "Camera Active" : 
                   cameraStatus === "requesting" ? "Requesting Access" : "Camera Denied"}
                </Badge>
              )}
              <Link to="/settings">
                <Button variant="ghost" size="sm">
                  <Settings className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8 space-y-8">
        {/* Stats Overview */}
        <div className="grid md:grid-cols-4 gap-6">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Today's Focus</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold text-primary">{todayFocus}%</div>
                <Eye className="h-5 w-5 text-primary" />
              </div>
              <Progress value={todayFocus} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Weekly Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold text-emotion-happy">{weeklyProgress}%</div>
                <TrendingUp className="h-5 w-5 text-emotion-happy" />
              </div>
              <Progress value={weeklyProgress} className="mt-2" />
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Current Mood</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <Badge className={getEmotionColor(currentEmotion)}>
                  {currentEmotion}
                </Badge>
                <Heart className="h-5 w-5 text-emotion-happy" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">Learning Streak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between">
                <div className="text-2xl font-bold text-emotion-focused">{streakDays}</div>
                <Target className="h-5 w-5 text-emotion-focused" />
              </div>
              <p className="text-sm text-muted-foreground mt-1">days in a row</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recommended Lessons */}
          <div className="lg:col-span-2 space-y-6">
            {/* Video Player with Attention Monitoring */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Play className="h-5 w-5" />
                  Learning Video Player
                  {isVideoPlaying && <Badge size="sm" className="animate-pulse">LIVE</Badge>}
                </CardTitle>
                <CardDescription>
                  Automatically pauses when you look away from the screen
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="relative bg-black rounded-xl overflow-hidden aspect-video">
                  <div className="absolute inset-0 bg-gradient-to-br from-blue-900 to-purple-900 flex items-center justify-center">
                    <div className="text-center text-white">
                      <div className="w-16 h-16 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                        {isVideoPlaying ? (
                          <Pause className="h-8 w-8" />
                        ) : (
                          <Play className="h-8 w-8 ml-1" />
                        )}
                      </div>
                      <p className="text-lg font-medium">
                        {isVideoPlaying ? "Video Playing" : "Demo Learning Video"}
                      </p>
                      <p className="text-sm opacity-75 mt-2">
                        {isVideoPlaying
                          ? "Look away to test automatic pause"
                          : "Click play to test attention monitoring"
                        }
                      </p>
                    </div>
                  </div>

                  {/* Attention overlay when looking away */}
                  {isVideoPlaying && !isLookingAtScreen && (
                    <div className="absolute inset-0 bg-red-900/80 flex items-center justify-center animate-in fade-in duration-300">
                      <div className="text-center text-white">
                        <AlertTriangle className="h-12 w-12 mx-auto mb-4 animate-bounce" />
                        <p className="text-xl font-bold mb-2">Video Paused</p>
                        <p className="text-sm">Please look at the screen to continue</p>
                        <p className="text-xs mt-2 opacity-75">
                          Redirecting to dashboard in {Math.max(0, 5 - awayFromScreenTime)}s
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between mt-4">
                  <Button
                    onClick={() => {
                      setIsVideoPlaying(!isVideoPlaying);
                      if (!isVideoPlaying) {
                        setAwayFromScreenTime(0);
                      }
                    }}
                    className="gap-2"
                  >
                    {isVideoPlaying ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                    {isVideoPlaying ? "Pause" : "Play"} Demo Video
                  </Button>

                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Eye className="h-4 w-4" />
                    <span>Attention: {attentionLevel}%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Recommended for You
                </CardTitle>
                <CardDescription>
                  Personalized course recommendations based on your learning patterns
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {recommendedCourses.map((course) => (
                  <div key={course.id} className="p-4 border rounded-lg hover:bg-accent/50 transition-colors">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-semibold mb-1">{course.title}</h3>
                        <p className="text-sm text-muted-foreground mb-2">{course.description}</p>
                        <div className="flex items-center gap-3 text-xs text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {course.duration}
                          </span>
                          <Badge size="sm" className={getDifficultyColor(course.difficulty)}>
                            {course.difficulty}
                          </Badge>
                        </div>
                      </div>
                      <Link to={`/learn/${course.id}`}>
                        <Button size="sm" className="gap-2">
                          <Play className="h-4 w-4" />
                          {course.progress > 0 ? "Continue" : "Start"}
                        </Button>
                      </Link>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{course.progress}%</span>
                      </div>
                      <Progress value={course.progress} className="h-2" />
                      {course.progress > 0 && (
                        <p className="text-xs text-muted-foreground">Next: {course.nextLesson}</p>
                      )}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Emotion Feedback Widget & AI Status */}
          <div className="space-y-6">
            {/* Emotion Feedback Widget */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Heart className="h-5 w-5" />
                  Emotion Monitor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {!isCameraActive ? (
                    <div className="text-center">
                      <Button 
                        onClick={startCamera} 
                        className="gap-2 w-full"
                        disabled={cameraStatus === "requesting"}
                      >
                        <Camera className="h-4 w-4" />
                        {cameraStatus === "requesting" ? "Requesting..." : "Enable Emotion Tracking"}
                      </Button>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <div className="relative bg-neutral-900 rounded-lg overflow-hidden aspect-video">
                        <video
                          ref={videoRef}
                          autoPlay
                          muted
                          playsInline
                          className="w-full h-full object-cover"
                          style={{ transform: "scaleX(-1)" }}
                        />
                        <canvas
                          ref={canvasRef}
                          className="absolute top-0 left-0 w-full h-full"
                          style={{ transform: "scaleX(-1)" }}
                        />
                      </div>
                      <div className="text-center">
                        <Button onClick={stopCamera} variant="outline" size="sm">
                          Stop Tracking
                        </Button>
                      </div>
                    </div>
                  )}
                  
                  {/* Recent Emotions */}
                  <div className="space-y-2">
                    <h4 className="font-medium text-sm">Recent Emotions</h4>
                    <div className="space-y-1">
                      {emotions.slice(-3).reverse().map((emotion, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <Badge size="sm" className={getEmotionColor(emotion.expression)}>
                            {emotion.expression}
                          </Badge>
                          <span className="text-muted-foreground">
                            {Math.floor(emotion.confidence * 100)}%
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Real-time Attention Level */}
            <Card className={`transition-all duration-300 ${attentionLevel < 50 ? 'border-red-200 bg-red-50/50' : attentionLevel > 80 ? 'border-green-200 bg-green-50/50' : ''}`}>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 text-lg">
                  <Eye className={`h-5 w-5 ${isEyeTrackingActive ? 'text-blue-600' : 'text-gray-400'}`} />
                  Live Attention Tracking
                  {isEyeTrackingActive && <Badge size="sm" variant="outline" className="text-xs">LIVE</Badge>}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className={`text-3xl font-bold transition-colors duration-300 ${
                      attentionLevel < 50 ? 'text-red-600' :
                      attentionLevel > 80 ? 'text-green-600' : 'text-primary'
                    }`}>
                      {attentionLevel}%
                    </div>
                    <p className="text-sm text-muted-foreground">Real-time Attention</p>
                  </div>

                  <Progress
                    value={attentionLevel}
                    className={`h-3 transition-all duration-300 ${
                      attentionLevel < 50 ? 'bg-red-100' :
                      attentionLevel > 80 ? 'bg-green-100' : ''
                    }`}
                  />

                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span>Eye Tracking:</span>
                      <Badge variant={isEyeTrackingActive ? "default" : "secondary"} size="sm">
                        {isEyeTrackingActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>

                    <div className="flex items-center justify-between text-sm">
                      <span>Looking at Screen:</span>
                      <Badge
                        variant={isLookingAtScreen ? "default" : "destructive"}
                        size="sm"
                        className={!isLookingAtScreen ? "animate-pulse" : ""}
                      >
                        {isLookingAtScreen ? "Yes" : "No"}
                      </Badge>
                    </div>

                    {lowAttentionCount > 0 && (
                      <div className="flex items-center justify-between text-sm">
                        <span>Low Attention Count:</span>
                        <Badge variant="destructive" size="sm" className="animate-bounce">
                          {lowAttentionCount}/3
                        </Badge>
                      </div>
                    )}
                  </div>

                  {attentionLevel < 50 && (
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg animate-pulse">
                      <div className="flex items-center gap-2 text-red-800">
                        <AlertTriangle className="h-4 w-4" />
                        <span className="text-sm font-medium">Low attention detected!</span>
                      </div>
                      <p className="text-xs text-red-600 mt-1">
                        An attention exercise will start automatically if this continues.
                      </p>
                    </div>
                  )}

                  {!isLookingAtScreen && (
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg animate-pulse">
                      <div className="flex items-center gap-2 text-orange-800">
                        <Eye className="h-4 w-4" />
                        <span className="text-sm font-medium">Please focus on the screen</span>
                      </div>
                      <p className="text-xs text-orange-600 mt-1">
                        Time away: {awayFromScreenTime}s
                        {awayFromScreenTime >= 3 && " (Video will pause soon)"}
                      </p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Learning Progress */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Recent Sessions
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {learningSessions.slice(0, 3).map((session, index) => (
                    <div key={index} className="space-y-2 pb-3 border-b last:border-b-0">
                      <div className="flex justify-between items-center">
                        <span className="font-medium text-sm">{session.topic}</span>
                        <Badge size="sm" className={getEmotionColor(session.emotionalState)}>
                          {session.emotionalState}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{session.duration}min</span>
                        <span>{session.engagementScore}% engaged</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Attention Training Video Modal */}
      {showAttentionVideo && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-4xl w-full max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between p-6 border-b bg-gradient-to-r from-red-50 to-orange-50">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 rounded-full animate-pulse">
                  <AlertTriangle className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold text-red-800">Attention Alert!</h3>
                  <p className="text-sm text-red-600">
                    Your focus level is below 50%. Let's do a quick attention exercise.
                  </p>
                </div>
              </div>
              <Badge variant="destructive" className="animate-bounce">
                Focus: {attentionLevel}%
              </Badge>
            </div>

            <div className="p-8">
              <div className="text-center space-y-6">
                <div className="relative">
                  <h2 className="text-2xl font-bold mb-2">
                    {attentionVideos[currentAttentionVideo]?.title}
                  </h2>
                  <p className="text-muted-foreground mb-6">
                    {attentionVideos[currentAttentionVideo]?.description}
                  </p>

                  {/* Attention Exercise Animation */}
                  {attentionVideos[currentAttentionVideo]?.type === "eye-exercise" && (
                    <div className="relative h-64 bg-gradient-to-br from-blue-50 to-purple-50 rounded-xl border-2 border-dashed border-blue-200 flex items-center justify-center overflow-hidden">
                      <div className="absolute inset-0">
                        <div className="w-4 h-4 bg-blue-500 rounded-full absolute animate-ping"
                             style={{
                               animation: "moveAroundScreen 6s infinite linear",
                               transformOrigin: "center"
                             }}>
                        </div>
                        <div className="w-3 h-3 bg-blue-600 rounded-full absolute"
                             style={{
                               animation: "moveAroundScreen 6s infinite linear",
                               transformOrigin: "center"
                             }}>
                        </div>
                      </div>
                      <div className="text-center z-10 bg-white/80 p-4 rounded-lg">
                        <Eye className="h-8 w-8 mx-auto mb-2 text-blue-600" />
                        <p className="font-medium text-blue-800">Follow the moving dot with your eyes</p>
                      </div>
                    </div>
                  )}

                  {attentionVideos[currentAttentionVideo]?.type === "breathing" && (
                    <div className="relative h-64 bg-gradient-to-br from-green-50 to-teal-50 rounded-xl border-2 border-dashed border-green-200 flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-24 h-24 bg-green-400 rounded-full mx-auto mb-4 animate-pulse"
                             style={{
                               animation: "breathe 4s infinite ease-in-out"
                             }}>
                        </div>
                        <div className="space-y-2">
                          <p className="font-medium text-green-800">Breathe in... Breathe out...</p>
                          <p className="text-sm text-green-600">Sync your breathing with the circle</p>
                        </div>
                      </div>
                    </div>
                  )}

                  {attentionVideos[currentAttentionVideo]?.type === "visual-tracking" && (
                    <div className="relative h-64 bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl border-2 border-dashed border-purple-200 flex items-center justify-center overflow-hidden">
                      <div className="absolute inset-0">
                        <div className="w-6 h-6 bg-purple-500 rounded-full absolute"
                             style={{
                               animation: "zigzag 8s infinite linear"
                             }}>
                        </div>
                        <div className="w-4 h-4 bg-pink-500 rounded-square absolute"
                             style={{
                               animation: "circle 10s infinite linear"
                             }}>
                        </div>
                      </div>
                      <div className="text-center z-10 bg-white/80 p-4 rounded-lg">
                        <Target className="h-8 w-8 mx-auto mb-2 text-purple-600" />
                        <p className="font-medium text-purple-800">Track the moving shapes</p>
                      </div>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-center gap-4">
                  <Button
                    onClick={() => {
                      setShowAttentionVideo(false);
                      setLowAttentionCount(0);
                    }}
                    variant="outline"
                  >
                    Skip Exercise
                  </Button>
                  <Button
                    onClick={() => {
                      setCurrentAttentionVideo((prev) => (prev + 1) % attentionVideos.length);
                    }}
                    className="gap-2"
                  >
                    <Play className="h-4 w-4" />
                    Next Exercise
                  </Button>
                </div>

                <div className="text-xs text-muted-foreground">
                  {isLookingAtScreen ? (
                    <span className="text-green-600">✓ You're focused on the screen</span>
                  ) : (
                    <span className="text-red-600 animate-pulse">⚠ Please look at the screen</span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Animated YouTube Video Suggestions Modal */}
      {showVideoSuggestions && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-center justify-center p-4 animate-in fade-in duration-300">
          <div className="bg-background rounded-2xl shadow-2xl border max-w-2xl w-full max-h-[90vh] overflow-hidden animate-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between p-6 border-b">
              <div className="flex items-center gap-3">
                <div className="p-2 bg-red-100 rounded-full">
                  <Youtube className="h-6 w-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-xl font-bold">Boost Your Focus</h3>
                  <p className="text-sm text-muted-foreground">
                    Your emotion confidence seems low. Try these helpful videos!
                  </p>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowVideoSuggestions(false)}
                className="rounded-full"
              >
                <X className="h-5 w-5" />
              </Button>
            </div>

            <div className="p-6 space-y-4 max-h-96 overflow-y-auto">
              {videoSuggestions.map((video, index) => (
                <div
                  key={video.id}
                  className="flex gap-4 p-4 border rounded-xl hover:bg-accent/50 transition-all duration-300 cursor-pointer group animate-in slide-in-from-left duration-700"
                  style={{ animationDelay: `${index * 100}ms` }}
                  onClick={() => {
                    window.open(`https://youtube.com/watch?v=${video.id}`, '_blank');
                  }}
                >
                  <div className="relative flex-shrink-0">
                    <img
                      src={video.thumbnail}
                      alt={video.title}
                      className="w-32 h-20 object-cover rounded-lg"
                    />
                    <div className="absolute inset-0 bg-black/20 rounded-lg flex items-center justify-center group-hover:bg-black/40 transition-colors">
                      <div className="w-8 h-8 bg-red-600 rounded-full flex items-center justify-center">
                        <Play className="h-4 w-4 text-white ml-0.5" />
                      </div>
                    </div>
                    <div className="absolute bottom-1 right-1 bg-black/80 text-white text-xs px-1 rounded">
                      {video.duration}
                    </div>
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-sm leading-tight mb-1 line-clamp-2 group-hover:text-primary transition-colors">
                      {video.title}
                    </h4>
                    <p className="text-xs text-muted-foreground mb-1">{video.channel}</p>
                    <p className="text-xs text-muted-foreground">{video.views}</p>
                    <div className="flex items-center gap-1 mt-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <ExternalLink className="h-3 w-3" />
                      <span className="text-xs">Watch on YouTube</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="p-6 border-t bg-muted/30">
              <div className="flex items-center justify-between">
                <p className="text-sm text-muted-foreground">
                  These videos can help improve your focus and emotional state
                </p>
                <Button
                  onClick={() => setShowVideoSuggestions(false)}
                  variant="outline"
                  size="sm"
                >
                  Maybe Later
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
